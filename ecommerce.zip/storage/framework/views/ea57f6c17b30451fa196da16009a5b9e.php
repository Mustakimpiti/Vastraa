

<?php $__env->startSection('title', 'Order Details - ' . $order->order_number); ?>
<?php $__env->startSection('page-title', 'Order Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="mb-3">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-secondary">
                <i class="fa fa-arrow-left"></i> Back to Orders
            </a>
            <a href="<?php echo e(route('admin.orders.invoice', $order)); ?>" 
               class="btn btn-info" 
               target="_blank">
                <i class="fa fa-file-text"></i> View Invoice
            </a>
            <?php if($order->order_status == 'cancelled'): ?>
            <form action="<?php echo e(route('admin.orders.destroy', $order)); ?>" 
                  method="POST" 
                  class="d-inline"
                  onsubmit="return confirm('Are you sure you want to delete this order?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i> Delete Order
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row">
    <!-- Order Information -->
    <div class="col-md-8">
        <!-- Order Items -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Items</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>SKU</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($item->saree_name); ?></strong><br>
                                    <small class="text-muted"><?php echo e($item->fabric); ?></small>
                                </td>
                                <td><?php echo e($item->saree_sku); ?></td>
                                <td>₹<?php echo e(number_format($item->price, 2)); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>₹<?php echo e(number_format($item->getSubtotal(), 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                <td><strong>₹<?php echo e(number_format($order->subtotal, 2)); ?></strong></td>
                            </tr>
                            <?php if($order->discount > 0): ?>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Discount:</strong></td>
                                <td><strong class="text-danger">-₹<?php echo e(number_format($order->discount, 2)); ?></strong></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td colspan="4" class="text-end"><strong>Shipping:</strong></td>
                                <td><strong>₹<?php echo e(number_format($order->shipping_cost, 2)); ?></strong></td>
                            </tr>
                            <tr class="table-primary">
                                <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                <td><strong>₹<?php echo e(number_format($order->total, 2)); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <!-- Billing Address -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Billing Address</h5>
            </div>
            <div class="card-body">
                <p class="mb-1"><strong><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></strong></p>
                <p class="mb-1"><?php echo e($order->street_address); ?></p>
                <?php if($order->apartment): ?>
                <p class="mb-1"><?php echo e($order->apartment); ?></p>
                <?php endif; ?>
                <p class="mb-1"><?php echo e($order->city); ?>, <?php echo e($order->state); ?> <?php echo e($order->zip); ?></p>
                <p class="mb-1"><?php echo e($order->country); ?></p>
                <p class="mb-1"><i class="fa fa-envelope"></i> <?php echo e($order->email); ?></p>
                <p class="mb-0"><i class="fa fa-phone"></i> <?php echo e($order->phone); ?></p>
            </div>
        </div>

        <!-- Shipping Address -->
        <?php if($order->ship_to_different): ?>
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Shipping Address</h5>
            </div>
            <div class="card-body">
                <p class="mb-1"><strong><?php echo e($order->shipping_first_name); ?> <?php echo e($order->shipping_last_name); ?></strong></p>
                <p class="mb-1"><?php echo e($order->shipping_street_address); ?></p>
                <?php if($order->shipping_apartment): ?>
                <p class="mb-1"><?php echo e($order->shipping_apartment); ?></p>
                <?php endif; ?>
                <p class="mb-1"><?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> <?php echo e($order->shipping_zip); ?></p>
                <p class="mb-0"><?php echo e($order->shipping_country); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Order Notes -->
        <?php if($order->order_notes): ?>
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Notes</h5>
            </div>
            <div class="card-body">
                <p class="mb-0"><?php echo e($order->order_notes); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div class="col-md-4">
        <!-- Order Summary -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Summary</h5>
            </div>
            <div class="card-body">
                <div class="row mb-2">
                    <div class="col-6 fw-bold">Order Number:</div>
                    <div class="col-6"><?php echo e($order->order_number); ?></div>
                </div>
                <div class="row mb-2">
                    <div class="col-6 fw-bold">Date:</div>
                    <div class="col-6"><?php echo e($order->created_at->format('M d, Y H:i')); ?></div>
                </div>
                <div class="row mb-2">
                    <div class="col-6 fw-bold">Payment Method:</div>
                    <div class="col-6"><?php echo e(ucfirst($order->payment_method)); ?></div>
                </div>
                <?php if($order->user): ?>
                <div class="row">
                    <div class="col-6 fw-bold">Customer:</div>
                    <div class="col-6">
                        <a href="#"><?php echo e($order->user->name); ?></a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Update Order Status -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Status</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.orders.update-status', $order)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group mb-3">
                        <label class="form-label">Current Status:</label>
                        <div>
                            <?php if($order->order_status == 'pending'): ?>
                                <span class="badge bg-warning">Pending</span>
                            <?php elseif($order->order_status == 'processing'): ?>
                                <span class="badge bg-info">Processing</span>
                            <?php elseif($order->order_status == 'completed'): ?>
                                <span class="badge bg-success">Completed</span>
                            <?php elseif($order->order_status == 'cancelled'): ?>
                                <span class="badge bg-danger">Cancelled</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="order_status" class="form-label">Update Status:</label>
                        <select name="order_status" id="order_status" class="form-control" required>
                            <option value="pending" <?php echo e($order->order_status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="processing" <?php echo e($order->order_status == 'processing' ? 'selected' : ''); ?>>Processing</option>
                            <option value="completed" <?php echo e($order->order_status == 'completed' ? 'selected' : ''); ?>>Completed</option>
                            <option value="cancelled" <?php echo e($order->order_status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                    </div>

                    <div class="form-group mb-3">
                        <label for="admin_notes" class="form-label">Admin Notes:</label>
                        <textarea name="admin_notes" id="admin_notes" class="form-control" rows="3" placeholder="Optional notes..."><?php echo e($order->admin_notes); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fa fa-save"></i> Update Status
                    </button>
                </form>
            </div>
        </div>

        <!-- Update Payment Status -->
        <div class="card mb-4">
            <div class="card-header bg-white">
                <h5 class="mb-0">Payment Status</h5>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.orders.update-payment-status', $order)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group mb-3">
                        <label class="form-label">Current Status:</label>
                        <div>
                            <?php if($order->payment_status == 'paid'): ?>
                                <span class="badge bg-success">Paid</span>
                            <?php elseif($order->payment_status == 'pending'): ?>
                                <span class="badge bg-warning">Pending</span>
                            <?php elseif($order->payment_status == 'failed'): ?>
                                <span class="badge bg-danger">Failed</span>
                            <?php elseif($order->payment_status == 'refunded'): ?>
                                <span class="badge bg-info">Refunded</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="payment_status" class="form-label">Update Status:</label>
                        <select name="payment_status" id="payment_status" class="form-control" required>
                            <option value="pending" <?php echo e($order->payment_status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="paid" <?php echo e($order->payment_status == 'paid' ? 'selected' : ''); ?>>Paid</option>
                            <option value="failed" <?php echo e($order->payment_status == 'failed' ? 'selected' : ''); ?>>Failed</option>
                            <option value="refunded" <?php echo e($order->payment_status == 'refunded' ? 'selected' : ''); ?>>Refunded</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success w-100">
                        <i class="fa fa-money"></i> Update Payment
                    </button>
                </form>
            </div>
        </div>

        <!-- Order Timeline -->
        <div class="card">
            <div class="card-header bg-white">
                <h5 class="mb-0">Order Timeline</h5>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <div class="timeline-item">
                        <small class="text-muted"><?php echo e($order->created_at->format('M d, Y H:i')); ?></small>
                        <p class="mb-0"><strong>Order Placed</strong></p>
                    </div>
                    <div class="timeline-item mt-3">
                        <small class="text-muted"><?php echo e($order->updated_at->format('M d, Y H:i')); ?></small>
                        <p class="mb-0"><strong>Last Updated</strong></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>