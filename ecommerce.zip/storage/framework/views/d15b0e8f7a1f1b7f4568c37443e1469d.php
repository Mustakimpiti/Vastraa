

<?php $__env->startSection('title', 'Contact Settings'); ?>
<?php $__env->startSection('page-title', 'Contact Settings'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .settings-section {
        background: white;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 25px;
        margin-bottom: 25px;
    }
    .settings-section h5 {
        color: #2c3e50;
        font-weight: 600;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid #3498db;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-label {
        font-weight: 600;
        color: #34495e;
        margin-bottom: 8px;
    }
    .form-text {
        font-size: 0.875rem;
        color: #6c757d;
    }
    .social-input-group {
        position: relative;
    }
    .social-input-group .input-icon {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #6c757d;
        z-index: 10;
    }
    .social-input-group input {
        padding-left: 35px;
    }
    .settings-tabs {
        border-bottom: 2px solid #dee2e6;
        margin-bottom: 30px;
    }
    .settings-tabs .nav-link {
        color: #6c757d;
        border: none;
        border-bottom: 2px solid transparent;
        padding: 12px 20px;
        margin-bottom: -2px;
    }
    .settings-tabs .nav-link:hover {
        color: #3498db;
        border-bottom-color: #3498db;
    }
    .settings-tabs .nav-link.active {
        color: #3498db;
        border-bottom-color: #3498db;
        font-weight: 600;
    }
    .save-btn-container {
        position: sticky;
        bottom: 0;
        background: white;
        padding: 20px;
        border-top: 2px solid #dee2e6;
        margin: 0 -30px -30px;
        text-align: right;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.settings.contact.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <!-- Navigation Tabs -->
    <ul class="nav settings-tabs">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#business-info">
                <i class="fa fa-building"></i> Business Info
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#contact-info">
                <i class="fa fa-phone"></i> Contact Info
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#address">
                <i class="fa fa-map-marker"></i> Address
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#business-hours">
                <i class="fa fa-clock-o"></i> Business Hours
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#social-media">
                <i class="fa fa-share-alt"></i> Social Media
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#map-location">
                <i class="fa fa-globe"></i> Map & Location
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#form-settings">
                <i class="fa fa-cogs"></i> Form Settings
            </a>
        </li>
    </ul>

    <div class="tab-content">
        <!-- Business Information Tab -->
        <div class="tab-pane fade show active" id="business-info">
            <div class="settings-section">
                <h5><i class="fa fa-building me-2"></i> Business Information</h5>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="business_name" class="form-label">Business Name *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="business_name" 
                                   name="business_name" 
                                   value="<?php echo e($settings['business_name']); ?>" 
                                   required>
                            <div class="form-text">Your official business/store name</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="business_tagline" class="form-label">Business Tagline</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="business_tagline" 
                                   name="business_tagline" 
                                   value="<?php echo e($settings['business_tagline']); ?>">
                            <div class="form-text">A short description of your business</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Information Tab -->
        <div class="tab-pane fade" id="contact-info">
            <div class="settings-section">
                <h5><i class="fa fa-envelope me-2"></i> Email Addresses</h5>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="contact_email" class="form-label">Primary Email *</label>
                            <input type="email" 
                                   class="form-control" 
                                   id="contact_email" 
                                   name="contact_email" 
                                   value="<?php echo e($settings['contact_email']); ?>" 
                                   required>
                            <div class="form-text">Main contact email</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="support_email" class="form-label">Support Email</label>
                            <input type="email" 
                                   class="form-control" 
                                   id="support_email" 
                                   name="support_email" 
                                   value="<?php echo e($settings['support_email']); ?>">
                            <div class="form-text">Customer support email</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="sales_email" class="form-label">Sales Email</label>
                            <input type="email" 
                                   class="form-control" 
                                   id="sales_email" 
                                   name="sales_email" 
                                   value="<?php echo e($settings['sales_email']); ?>">
                            <div class="form-text">Sales inquiries email</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="settings-section">
                <h5><i class="fa fa-phone me-2"></i> Phone Numbers</h5>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="contact_phone" class="form-label">Primary Phone *</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="contact_phone" 
                                   name="contact_phone" 
                                   value="<?php echo e($settings['contact_phone']); ?>" 
                                   required>
                            <div class="form-text">Main contact number</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="whatsapp_number" class="form-label">WhatsApp Number</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="whatsapp_number" 
                                   name="whatsapp_number" 
                                   value="<?php echo e($settings['whatsapp_number']); ?>">
                            <div class="form-text">Include country code (e.g., +91)</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="alternate_phone" class="form-label">Alternate Phone</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="alternate_phone" 
                                   name="alternate_phone" 
                                   value="<?php echo e($settings['alternate_phone']); ?>">
                            <div class="form-text">Secondary contact number</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Address Tab -->
        <div class="tab-pane fade" id="address">
            <div class="settings-section">
                <h5><i class="fa fa-map-marker me-2"></i> Business Address</h5>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="street_address" class="form-label">Street Address</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="street_address" 
                                   name="street_address" 
                                   value="<?php echo e($settings['street_address']); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="city" class="form-label">City</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="city" 
                                   name="city" 
                                   value="<?php echo e($settings['city']); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="state" class="form-label">State/Province</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="state" 
                                   name="state" 
                                   value="<?php echo e($settings['state']); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="postal_code" class="form-label">Postal Code</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="postal_code" 
                                   name="postal_code" 
                                   value="<?php echo e($settings['postal_code']); ?>">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="country" class="form-label">Country</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="country" 
                                   name="country" 
                                   value="<?php echo e($settings['country']); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Business Hours Tab -->
        <div class="tab-pane fade" id="business-hours">
            <div class="settings-section">
                <h5><i class="fa fa-clock-o me-2"></i> Operating Hours</h5>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="business_hours_weekday" class="form-label">Monday - Friday</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="business_hours_weekday" 
                                   name="business_hours_weekday" 
                                   value="<?php echo e($settings['business_hours_weekday']); ?>"
                                   placeholder="9:00 AM - 6:00 PM">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="business_hours_saturday" class="form-label">Saturday</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="business_hours_saturday" 
                                   name="business_hours_saturday" 
                                   value="<?php echo e($settings['business_hours_saturday']); ?>"
                                   placeholder="10:00 AM - 4:00 PM">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="business_hours_sunday" class="form-label">Sunday</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="business_hours_sunday" 
                                   name="business_hours_sunday" 
                                   value="<?php echo e($settings['business_hours_sunday']); ?>"
                                   placeholder="Closed">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Social Media Tab -->
        <div class="tab-pane fade" id="social-media">
            <div class="settings-section">
                <h5><i class="fa fa-share-alt me-2"></i> Social Media Links</h5>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="facebook_url" class="form-label">Facebook URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-facebook input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="facebook_url" 
                                       name="facebook_url" 
                                       value="<?php echo e($settings['facebook_url']); ?>"
                                       placeholder="https://facebook.com/yourpage">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="instagram_url" class="form-label">Instagram URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-instagram input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="instagram_url" 
                                       name="instagram_url" 
                                       value="<?php echo e($settings['instagram_url']); ?>"
                                       placeholder="https://instagram.com/yourprofile">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="twitter_url" class="form-label">Twitter URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-twitter input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="twitter_url" 
                                       name="twitter_url" 
                                       value="<?php echo e($settings['twitter_url']); ?>"
                                       placeholder="https://twitter.com/yourhandle">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="pinterest_url" class="form-label">Pinterest URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-pinterest input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="pinterest_url" 
                                       name="pinterest_url" 
                                       value="<?php echo e($settings['pinterest_url']); ?>"
                                       placeholder="https://pinterest.com/yourprofile">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="youtube_url" class="form-label">YouTube URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-youtube input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="youtube_url" 
                                       name="youtube_url" 
                                       value="<?php echo e($settings['youtube_url']); ?>"
                                       placeholder="https://youtube.com/yourchannel">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="linkedin_url" class="form-label">LinkedIn URL</label>
                            <div class="social-input-group">
                                <i class="fa fa-linkedin input-icon"></i>
                                <input type="url" 
                                       class="form-control" 
                                       id="linkedin_url" 
                                       name="linkedin_url" 
                                       value="<?php echo e($settings['linkedin_url']); ?>"
                                       placeholder="https://linkedin.com/company/yourcompany">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map & Location Tab -->
        <div class="tab-pane fade" id="map-location">
            <div class="settings-section">
                <h5><i class="fa fa-globe me-2"></i> Map & Location Settings</h5>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="latitude" class="form-label">Latitude</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="latitude" 
                                   name="latitude" 
                                   value="<?php echo e($settings['latitude']); ?>"
                                   placeholder="28.7041">
                            <div class="form-text">Decimal degrees format</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="longitude" class="form-label">Longitude</label>
                            <input type="text" 
                                   class="form-control" 
                                   id="longitude" 
                                   name="longitude" 
                                   value="<?php echo e($settings['longitude']); ?>"
                                   placeholder="77.1025">
                            <div class="form-text">Decimal degrees format</div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="google_maps_embed" class="form-label">Google Maps Embed Code</label>
                            <textarea class="form-control" 
                                      id="google_maps_embed" 
                                      name="google_maps_embed" 
                                      rows="4"
                                      placeholder='<iframe src="https://www.google.com/maps/embed?..." ...></iframe>'><?php echo e($settings['google_maps_embed']); ?></textarea>
                            <div class="form-text">
                                Get embed code from <a href="https://www.google.com/maps" target="_blank">Google Maps</a> 
                                (Share → Embed a map)
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Settings Tab -->
        <div class="tab-pane fade" id="form-settings">
            <div class="settings-section">
                <h5><i class="fa fa-cogs me-2"></i> Contact Form Configuration</h5>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-switch">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       id="enable_contact_form" 
                                       name="enable_contact_form" 
                                       value="1"
                                       <?php echo e($settings['enable_contact_form'] == '1' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="enable_contact_form">
                                    <strong>Enable Contact Form</strong>
                                </label>
                            </div>
                            <div class="form-text">Allow customers to submit contact form on website</div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-switch">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       id="contact_form_email_notification" 
                                       name="contact_form_email_notification" 
                                       value="1"
                                       <?php echo e($settings['contact_form_email_notification'] == '1' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="contact_form_email_notification">
                                    <strong>Email Notifications</strong>
                                </label>
                            </div>
                            <div class="form-text">Send email notification when a new contact form is submitted</div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="form-check form-switch">
                                <input class="form-check-input" 
                                       type="checkbox" 
                                       id="contact_form_auto_reply" 
                                       name="contact_form_auto_reply" 
                                       value="1"
                                       <?php echo e($settings['contact_form_auto_reply'] == '1' ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="contact_form_auto_reply">
                                    <strong>Auto Reply</strong>
                                </label>
                            </div>
                            <div class="form-text">Send automatic reply to customers after form submission</div>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="contact_form_auto_reply_message" class="form-label">Auto Reply Message</label>
                            <textarea class="form-control" 
                                      id="contact_form_auto_reply_message" 
                                      name="contact_form_auto_reply_message" 
                                      rows="5"
                                      placeholder="Thank you for contacting us! We'll get back to you soon."><?php echo e($settings['contact_form_auto_reply_message']); ?></textarea>
                            <div class="form-text">This message will be sent to customers when auto-reply is enabled</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sticky Save Button -->
    <div class="save-btn-container">
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="fa fa-save"></i> Save All Settings
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-save indication (optional)
    document.querySelectorAll('input, textarea, select').forEach(element => {
        element.addEventListener('change', function() {
            // You can add visual feedback here that settings need to be saved
            console.log('Settings modified');
        });
    });

    // Validate URLs
    document.querySelectorAll('input[type="url"]').forEach(input => {
        input.addEventListener('blur', function() {
            if (this.value && !this.value.startsWith('http')) {
                this.value = 'https://' + this.value;
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/settings/contact.blade.php ENDPATH**/ ?>