

<?php $__env->startSection('title', 'Manage Sarees'); ?>
<?php $__env->startSection('page-title', 'Manage Sarees'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">All Sarees</h5>
        <a href="<?php echo e(route('admin.sarees.create')); ?>" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Saree
        </a>
    </div>
    <div class="card-body">
        <?php if($sarees->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>SKU</th>
                        <th>Fabric</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sarees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
    <?php if($saree->featured_image): ?>
        <img src="<?php echo e(asset($saree->featured_image)); ?>" 
             alt="<?php echo e($saree->name); ?>" 
             class="saree-img-thumb">
    <?php else: ?>
        <div class="saree-img-thumb bg-secondary d-flex align-items-center justify-content-center">
            <i class="fa fa-image text-white"></i>
        </div>
    <?php endif; ?>
</td>
                        <td>
                            <strong><?php echo e($saree->name); ?></strong><br>
                            <small class="text-muted"><?php echo e($saree->collection->name ?? 'No Collection'); ?></small>
                        </td>
                        <td><?php echo e($saree->sku); ?></td>
                        <td><?php echo e($saree->fabric); ?></td>
                        <td>
                            <?php if($saree->sale_price): ?>
                                <span class="text-decoration-line-through text-muted">₹<?php echo e(number_format($saree->price, 2)); ?></span><br>
                                <span class="text-danger fw-bold">₹<?php echo e(number_format($saree->sale_price, 2)); ?></span>
                            <?php else: ?>
                                <span class="fw-bold">₹<?php echo e(number_format($saree->price, 2)); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($saree->stock_quantity > 10): ?>
                                <span class="badge bg-success"><?php echo e($saree->stock_quantity); ?></span>
                            <?php elseif($saree->stock_quantity > 0): ?>
                                <span class="badge bg-warning"><?php echo e($saree->stock_quantity); ?></span>
                            <?php else: ?>
                                <span class="badge bg-danger">Out of Stock</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($saree->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                            <?php if($saree->is_featured): ?>
                                <span class="badge bg-primary">Featured</span>
                            <?php endif; ?>
                            <?php if($saree->is_new_arrival): ?>
                                <span class="badge bg-info">New</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.sarees.show', $saree)); ?>" 
                               class="btn btn-sm btn-info btn-action" 
                               title="View">
                                <i class="fa fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('admin.sarees.edit', $saree)); ?>" 
                               class="btn btn-sm btn-warning btn-action" 
                               title="Edit">
                                <i class="fa fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.sarees.destroy', $saree)); ?>" 
                                  method="POST" 
                                  class="d-inline"
                                  onsubmit="return confirm('Are you sure you want to delete this saree?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" 
                                        class="btn btn-sm btn-danger btn-action" 
                                        title="Delete">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($sarees->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fa fa-shopping-bag fa-3x text-muted mb-3"></i>
            <p class="text-muted">No sarees found. Add your first saree to get started!</p>
            <a href="<?php echo e(route('admin.sarees.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i> Add New Saree
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/sarees/index.blade.php ENDPATH**/ ?>