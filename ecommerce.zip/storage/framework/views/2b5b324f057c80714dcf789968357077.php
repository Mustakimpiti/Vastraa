

<?php $__env->startSection('title', 'Checkout - Saree Shop'); ?>

<?php $__env->startSection('content'); ?>
<!--== Start Page Title Area ==-->
<section class="page-title-area bg-img" data-bg-img="<?php echo e(asset('assets/img/photos/bg-page1.jpg')); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-title-content">
                    <h2 class="title">Checkout</h2>
                    <div class="bread-crumbs">
                        <a href="<?php echo e(route('home')); ?>">Home<span class="breadcrumb-sep">></span></a>
                        <span class="active">Checkout</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== End Page Title Area ==-->

<!--== Start Shop Checkout Area ==-->
<section class="shop-checkout-area">
    <div class="container">
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <?php if(auth()->guard()->guest()): ?>
            <div class="col-md-12">
                <div class="shop-return-login" id="returnloginAccordion">
                    <div class="card">
                        <h6>Returning customer? <span data-bs-toggle="collapse" data-bs-target="#returnloginaccordion"> Click here to login</span></h6>
                        <div id="returnloginaccordion" class="collapse" data-bs-parent="#returnloginAccordion">
                            <div class="card-body">
                                <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing & Shipping section.</p>
                                <form action="<?php echo e(route('login')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="rl_username">Username or email <span class="required">*</span></label>
                                        <input class="form-control" id="rl_username" name="email" type="text" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="rl_password">Password <span class="required">*</span></label>
                                        <input class="form-control" id="rl_password" name="password" type="password" required>
                                    </div>
                                    <button class="btn btn-coupon w-100" type="submit">Login</button>
                                    <div class="remember-lostpassword">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="RadioRememberMe" name="remember">
                                            <label class="custom-control-label ps-1" for="RadioRememberMe">Remember me</label>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="col-md-12">
                <div class="shop-checkout-coupon" id="checkoutloginAccordion">
                    <div class="card">
                        <h6>Have a coupon? <span data-bs-toggle="collapse" data-bs-target="#couponaccordion"> Click here to enter your code</span></h6>
                        <div id="couponaccordion" class="collapse <?php echo e($couponCode ? 'show' : ''); ?>" data-bs-parent="#checkoutloginAccordion">
                            <div class="card-body">
                                <?php if($couponCode): ?>
                                <div class="alert alert-success">
                                    Coupon code <strong><?php echo e($couponCode); ?></strong> applied successfully! You saved ₹<?php echo e(number_format($discount, 2)); ?>

                                    <form action="<?php echo e(route('cart.coupon.remove')); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-link text-danger p-0">Remove</button>
                                    </form>
                                </div>
                                <?php else: ?>
                                <p>If you have a coupon code, please apply it below.</p>
                                <form action="<?php echo e(route('cart.coupon.apply')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <input class="form-control" type="text" name="coupon_code" placeholder="Enter Your Coupon Code" required>
                                    </div>
                                    <button class="btn btn-coupon" type="submit">Apply Coupon</button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="shop-billing-form">
                    <form action="<?php echo e(route('checkout.process')); ?>" method="post" id="checkout-form">
                        <?php echo csrf_field(); ?>

                        <?php if(auth()->guard()->check()): ?>
                        <?php if($savedAddresses->count() > 0): ?>
                        <!-- Saved Addresses Section -->
                        <div class="mb-4">
                            <h4 class="title">Select Saved Address</h4>
                            <div class="saved-addresses-list">
                                <?php $__currentLoopData = $savedAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="saved-address-card <?php echo e($address->is_default ? 'default-address' : ''); ?>" data-address-id="<?php echo e($address->id); ?>">
                                    <div class="form-check">
                                        <input class="form-check-input address-radio" 
                                               type="radio" 
                                               name="saved_address_id" 
                                               id="address_<?php echo e($address->id); ?>"
                                               value="<?php echo e($address->id); ?>"
                                               <?php echo e($address->is_default ? 'checked' : ''); ?>>
                                        <label class="form-check-label w-100" for="address_<?php echo e($address->id); ?>">
                                            <div class="address-content">
                                                <div class="address-header">
                                                    <strong><?php echo e($address->full_name); ?></strong>
                                                    <?php if($address->is_default): ?>
                                                    <span class="badge bg-success ms-2">Default</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="address-details">
                                                    <p class="mb-1"><?php echo e($address->street_address); ?><?php echo e($address->apartment ? ', ' . $address->apartment : ''); ?></p>
                                                    <p class="mb-1"><?php echo e($address->city); ?>, <?php echo e($address->state); ?> <?php echo e($address->zip); ?></p>
                                                    <p class="mb-1"><?php echo e($address->country); ?></p>
                                                    <p class="mb-0"><strong>Phone:</strong> <?php echo e($address->phone); ?></p>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            <div class="mt-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="use_new_address" name="use_new_address">
                                    <label class="form-check-label" for="use_new_address">
                                        Use a different address or add new address
                                    </label>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>

                        <div id="billing-details-section" class="<?php echo e(Auth::check() && $savedAddresses->count() > 0 ? 'd-none' : ''); ?>">
                            <h4 class="title">Billing details</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="cf_name">First name <abbr class="required" title="required">*</abbr></label>
                                        <input class="form-control billing-field" id="cf_name" name="first_name" type="text" value="<?php echo e(old('first_name', $defaultAddress->first_name ?? Auth::user()->name ?? '')); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="cf_last_name">Last name <abbr class="required" title="required">*</abbr></label>
                                        <input class="form-control billing-field" id="cf_last_name" name="last_name" type="text" value="<?php echo e(old('last_name', $defaultAddress->last_name ?? '')); ?>" required>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="cf_country_region">Country / Region <abbr class="required" title="required">*</abbr></label>
                                <select class="form-control niceselect billing-field" id="cf_country_region" name="country" required>
                                    <option value="India" <?php echo e(old('country', $defaultAddress->country ?? 'India') == 'India' ? 'selected' : ''); ?>>India</option>
                                    <option value="United States" <?php echo e(old('country', $defaultAddress->country ?? '') == 'United States' ? 'selected' : ''); ?>>United States (US)</option>
                                    <option value="United Kingdom" <?php echo e(old('country', $defaultAddress->country ?? '') == 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom (UK)</option>
                                    <option value="Bangladesh" <?php echo e(old('country', $defaultAddress->country ?? '') == 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>
                                    <option value="Pakistan" <?php echo e(old('country', $defaultAddress->country ?? '') == 'Pakistan' ? 'selected' : ''); ?>>Pakistan</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="cf_street_address">Street address <abbr class="required" title="required">*</abbr></label>
                                <input class="form-control billing-field" id="cf_street_address" name="street_address" type="text" placeholder="House number and street name" value="<?php echo e(old('street_address', $defaultAddress->street_address ?? '')); ?>" required>
                            </div>

                            <div class="form-group">
                                <input class="form-control billing-field" name="apartment" type="text" placeholder="Apartment, suite, unit, etc. (optional)" value="<?php echo e(old('apartment', $defaultAddress->apartment ?? '')); ?>">
                            </div>

                            <div class="form-group">
                                <label for="cf_town_city">Town / City <abbr class="required" title="required">*</abbr></label>
                                <input class="form-control billing-field" id="cf_town_city" name="city" type="text" value="<?php echo e(old('city', $defaultAddress->city ?? '')); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="cf_state_region">State <abbr class="required" title="required">*</abbr></label>
                                <select class="form-control niceselect billing-field" id="cf_state_region" name="state" required>
                                    <option value="">Select State</option>
                                    <option value="Gujarat" <?php echo e(old('state', $defaultAddress->state ?? '') == 'Gujarat' ? 'selected' : ''); ?>>Gujarat</option>
                                    <option value="Maharashtra" <?php echo e(old('state', $defaultAddress->state ?? '') == 'Maharashtra' ? 'selected' : ''); ?>>Maharashtra</option>
                                    <option value="Karnataka" <?php echo e(old('state', $defaultAddress->state ?? '') == 'Karnataka' ? 'selected' : ''); ?>>Karnataka</option>
                                    <!-- Add other states -->
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="cf_zip">ZIP <abbr class="required" title="required">*</abbr></label>
                                <input class="form-control billing-field" id="cf_zip" name="zip" type="text" value="<?php echo e(old('zip', $defaultAddress->zip ?? '')); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="cf_phone">Phone <abbr class="required" title="required">*</abbr></label>
                                <input class="form-control billing-field" id="cf_phone" name="phone" type="text" value="<?php echo e(old('phone', $defaultAddress->phone ?? '')); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="cf_email">Email address <abbr class="required" title="required">*</abbr></label>
                                <input class="form-control" id="cf_email" name="email" type="email" value="<?php echo e(old('email', Auth::user()->email ?? '')); ?>" required>
                            </div>

                            <?php if(auth()->guard()->check()): ?>
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="save_address" name="save_address" value="1">
                                    <label class="custom-control-label" for="save_address">
                                        Save this address for future orders
                                    </label>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="checkout-box-wrap ship-different-address mt-4">
                            <div class="form-group">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" 
                                        class="custom-control-input" 
                                        id="ship_to_different" 
                                        name="ship_to_different" 
                                        value="1" 
                                        <?php echo e(old('ship_to_different') ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="ship_to_different">
                                        Ship to a different address?
                                    </label>
                                </div>
                            </div>
                            <div class="ship-to-different single-form-row" style="display: none;">
                                <div class="form-group">
                                    <label for="cf_name_2">First name <abbr class="required" title="required">*</abbr></label>
                                    <input class="form-control shipping-field" id="cf_name_2" name="shipping_first_name" type="text" value="<?php echo e(old('shipping_first_name')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cf_last_name_2">Last name <abbr class="required" title="required">*</abbr></label>
                                    <input class="form-control shipping-field" id="cf_last_name_2" name="shipping_last_name" type="text" value="<?php echo e(old('shipping_last_name')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cf_country_region_2">Country / Region <abbr class="required" title="required">*</abbr></label>
                                    <select class="form-control niceselect shipping-field" id="cf_country_region_2" name="shipping_country">
                                        <option value="India" <?php echo e(old('shipping_country', 'India') == 'India' ? 'selected' : ''); ?>>India</option>
                                        <option value="United States" <?php echo e(old('shipping_country') == 'United States' ? 'selected' : ''); ?>>United States (US)</option>
                                        <option value="United Kingdom" <?php echo e(old('shipping_country') == 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom (UK)</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="cf_street_address_2">Street address <abbr class="required" title="required">*</abbr></label>
                                    <input class="form-control shipping-field" id="cf_street_address_2" name="shipping_street_address" type="text" placeholder="House number and street name" value="<?php echo e(old('shipping_street_address')); ?>">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" name="shipping_apartment" type="text" placeholder="Apartment, suite, unit, etc. (optional)" value="<?php echo e(old('shipping_apartment')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cf_town_city_2">Town / City <abbr class="required" title="required">*</abbr></label>
                                    <input class="form-control shipping-field" id="cf_town_city_2" name="shipping_city" type="text" value="<?php echo e(old('shipping_city')); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="cf_state_region_2">State <abbr class="required" title="required">*</abbr></label>
                                    <select class="form-control niceselect shipping-field" id="cf_state_region_2" name="shipping_state">
                                        <option value="">Select State</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="Maharashtra">Maharashtra</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="cf_zip_2">ZIP <abbr class="required" title="required">*</abbr></label>
                                    <input class="form-control shipping-field" id="cf_zip_2" name="shipping_zip" type="text" value="<?php echo e(old('shipping_zip')); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-group mt-4">
                            <label for="cf_order_notes">Order notes (optional)</label>
                            <textarea class="form-control" name="order_notes" id="cf_order_notes" placeholder="Notes about your order, e.g. special notes for delivery."><?php echo e(old('order_notes')); ?></textarea>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <!-- Order summary and payment methods remain the same as before -->
                <h4 class="title">Your order</h4>
                <div class="order-review-details">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="product-title"><?php echo e($item->saree->name); ?></span>
                                    <span class="product-quantity"> × <?php echo e($item->quantity); ?></span>
                                </td>
                                <td>₹<?php echo e(number_format($item->getSubtotal(), 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="cart-subtotal">
                                <th>Subtotal</th>
                                <td>₹<?php echo e(number_format($subtotal, 2)); ?></td>
                            </tr>
                            <?php if($discount > 0): ?>
                            <tr class="cart-discount">
                                <th>Discount</th>
                                <td class="text-success">-₹<?php echo e(number_format($discount, 2)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr class="shipping">
                                <th>Shipping</th>
                                <td>₹<?php echo e(number_format($shippingCost, 2)); ?></td>
                            </tr>
                            <tr class="final-total">
                                <th>Total</th>
                                <td><span class="total-amount">₹<?php echo e(number_format($total, 2)); ?></span></td>
                            </tr>
                        </tfoot>
                    </table>

                    <!-- Payment methods section -->
                    <div class="shop-payment-method">
                        <div id="accordion">
                            <!-- Direct Bank Transfer -->
                            <div class="card payment-card">
                                <div class="card-header" id="direct_bank_transfer" data-payment="payment_bank">
                                    <h5 class="mb-0">
                                        <div class="payment-option" data-bs-toggle="collapse" data-bs-target="#itemOne" aria-expanded="false" aria-controls="itemOne">
                                            <div class="radio-wrapper">
                                                <input type="radio" id="payment_bank" name="payment_method" value="bank_transfer" form="checkout-form" <?php echo e(old('payment_method') == 'bank_transfer' ? 'checked' : ''); ?> required>
                                                <label for="payment_bank" class="payment-label">
                                                    <span class="payment-title">Direct Bank Transfer</span>
                                                </label>
                                            </div>
                                            <span class="collapse-icon">▼</span>
                                        </div>
                                    </h5>
                                </div>
                                <div id="itemOne" class="collapse" aria-labelledby="direct_bank_transfer" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Check Payments -->
                            <div class="card payment-card">
                                <div class="card-header" id="check_payments" data-payment="payment_check">
                                    <h5 class="mb-0">
                                        <div class="payment-option" data-bs-toggle="collapse" data-bs-target="#itemTwo" aria-expanded="false" aria-controls="itemTwo">
                                            <div class="radio-wrapper">
                                                <input type="radio" id="payment_check" name="payment_method" value="check" form="checkout-form" <?php echo e(old('payment_method') == 'check' ? 'checked' : ''); ?> required>
                                                <label for="payment_check" class="payment-label">
                                                    <span class="payment-title">Check Payments</span>
                                                </label>
                                            </div>
                                            <span class="collapse-icon">▼</span>
                                        </div>
                                    </h5>
                                </div>
                                <div id="itemTwo" class="collapse" aria-labelledby="check_payments" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <p>Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- Cash on Delivery -->
                            <div class="card payment-card">
                                <div class="card-header" id="cash_on_delivery" data-payment="payment_cod">
                                    <h5 class="mb-0">
                                        <div class="payment-option" data-bs-toggle="collapse" data-bs-target="#itemThree" aria-expanded="false" aria-controls="itemThree">
                                            <div class="radio-wrapper">
                                                <input type="radio" id="payment_cod" name="payment_method" value="cod" form="checkout-form" <?php echo e(old('payment_method') == 'cod' ? 'checked' : ''); ?> required>
                                                <label for="payment_cod" class="payment-label">
                                                    <span class="payment-title">Cash on Delivery</span>
                                                </label>
                                            </div>
                                            <span class="collapse-icon">▼</span>
                                        </div>
                                    </h5>
                                </div>
                                <div id="itemThree" class="collapse" aria-labelledby="cash_on_delivery" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <p>Pay with cash upon delivery.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- PayPal -->
                            <div class="card payment-card">
                                <div class="card-header" id="Pay_Pal" data-payment="payment_paypal">
                                    <h5 class="mb-0">
                                        <div class="payment-option" data-bs-toggle="collapse" data-bs-target="#item4" aria-expanded="false" aria-controls="item4">
                                            <div class="radio-wrapper">
                                                <input type="radio" id="payment_paypal" name="payment_method" value="paypal" form="checkout-form" <?php echo e(old('payment_method') == 'paypal' ? 'checked' : ''); ?> required>
                                                <label for="payment_paypal" class="payment-label">
                                                    <span class="payment-icon">
                                                        <img src="<?php echo e(asset('assets/img/icons/paypal.png')); ?>" alt="PayPal" style="height: 24px;">
                                                    </span>
                                                    <span class="payment-title">PayPal</span>
                                                    <a href="#/" class="info-link">What is PayPal?</a>
                                                </label>
                                            </div>
                                            <span class="collapse-icon">▼</span>
                                        </div>
                                    </h5>
                                </div>
                                <div id="item4" class="collapse" aria-labelledby="Pay_Pal" data-bs-parent="#accordion">
                                    <div class="card-body">
                                        <p>Pay via PayPal; you can pay with your credit card if you don't have a PayPal account.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn place-order-btn" type="submit" form="checkout-form">Place order</button>
            </div>
        </div>
    </div>
</section>

<style>
.saved-addresses-list {
    display: grid;
    gap: 15px;
    margin-bottom: 20px;
}

.saved-address-card {
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    padding: 15px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.saved-address-card:hover {
    border-color: #3b82f6;
    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
}

.saved-address-card.selected {
    border-color: #3b82f6;
    background-color: #eff6ff;
}

.saved-address-card.default-address {
    border-color: #10b981;
}

.address-radio {
    width: 20px;
    height: 20px;
    margin-right: 12px;
}

.address-content {
    flex: 1;
}

.address-header {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
}

.address-details {
    font-size: 14px;
    color: #6b7280;
}

.address-details p {
    line-height: 1.5;
}

/* Payment Method Styles */
.shop-payment-method {
    margin-top: 25px;
}

.payment-card {
    border: 2px solid #e5e7eb;
    border-radius: 8px;
    margin-bottom: 12px;
    transition: all 0.3s ease;
    background: #ffffff;
    overflow: hidden;
}

.payment-card:hover {
    border-color: #d1d5db;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.payment-card.selected {
    border-color: #3b82f6;
    background: #eff6ff;
}

.payment-card .card-header {
    background: transparent;
    border: none;
    padding: 0;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.payment-card .card-header:hover {
    background: #f9fafb;
}

.payment-card.selected .card-header {
    background: #dbeafe;
}

.payment-option {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 20px;
    width: 100%;
}

.radio-wrapper {
    display: flex;
    align-items: center;
    flex: 1;
    gap: 12px;
}

.radio-wrapper input[type="radio"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
    margin: 0;
    accent-color: #3b82f6;
}

.payment-label {
    display: flex;
    align-items: center;
    gap: 12px;
    cursor: pointer;
    margin: 0;
    font-weight: 500;
    color: #1f2937;
    flex: 1;
}

.payment-icon {
    font-size: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.payment-title {
    font-size: 16px;
    font-weight: 600;
}

.info-link {
    font-size: 13px;
    color: #3b82f6;
    text-decoration: none;
    margin-left: 8px;
    font-weight: 400;
}

.info-link:hover {
    text-decoration: underline;
}

.collapse-icon {
    color: #6b7280;
    font-size: 12px;
    transition: transform 0.3s ease;
    margin-right: 5px;
}

.payment-option[aria-expanded="true"] .collapse-icon {
    transform: rotate(180deg);
}

.payment-card .card-body {
    padding: 15px 20px 20px 52px;
    background: #f9fafb;
    border-top: 1px solid #e5e7eb;
}

.payment-card .card-body p {
    margin: 0;
    color: #6b7280;
    font-size: 14px;
    line-height: 1.6;
}

/* Responsive Design */
@media (max-width: 768px) {
    .payment-option {
        padding: 15px;
    }
    
    .payment-title {
        font-size: 15px;
    }
    
    .payment-card .card-body {
        padding: 12px 15px 15px 45px;
    }
    
    .info-link {
        display: block;
        margin-left: 0;
        margin-top: 4px;
    }
}

/* Animation for selection */
@keyframes pulse {
    0%, 100% {
        opacity: 1;
    }
    50% {
        opacity: 0.8;
    }
}

.payment-card.selected {
    animation: pulse 0.3s ease-in-out;
}
</style>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const savedAddressCards = document.querySelectorAll('.saved-address-card');
    const useNewAddressCheckbox = document.getElementById('use_new_address');
    const billingDetailsSection = document.getElementById('billing-details-section');
    const billingFields = document.querySelectorAll('.billing-field');
    const addressRadios = document.querySelectorAll('.address-radio');

    // Handle saved address selection
    savedAddressCards.forEach(card => {
        card.addEventListener('click', function() {
            const radio = this.querySelector('.address-radio');
            radio.checked = true;
            updateAddressSelection();
            loadAddressData(radio.value);
        });
    });

    // Handle address radio change
    addressRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                loadAddressData(this.value);
            }
        });
    });

    // Update visual selection
    function updateAddressSelection() {
        savedAddressCards.forEach(card => {
            card.classList.remove('selected');
        });
        const selectedCard = document.querySelector('.address-radio:checked')?.closest('.saved-address-card');
        if (selectedCard) {
            selectedCard.classList.add('selected');
        }
    }

    // Load address data into form
    function loadAddressData(addressId) {
        if (!addressId) return;

        fetch(`/api/address/${addressId}`)
            .then(response => response.json())
            .then(address => {
                document.getElementById('cf_name').value = address.first_name;
                document.getElementById('cf_last_name').value = address.last_name;
                document.getElementById('cf_street_address').value = address.street_address;
                document.querySelector('[name="apartment"]').value = address.apartment || '';
                document.getElementById('cf_town_city').value = address.city;
                document.getElementById('cf_state_region').value = address.state;
                document.getElementById('cf_country_region').value = address.country;
                document.getElementById('cf_zip').value = address.zip;
                document.getElementById('cf_phone').value = address.phone;
            })
            .catch(error => console.error('Error loading address:', error));
    }

    // Handle "use new address" checkbox
    if (useNewAddressCheckbox) {
        useNewAddressCheckbox.addEventListener('change', function() {
            if (this.checked) {
                billingDetailsSection.classList.remove('d-none');
                billingFields.forEach(field => field.setAttribute('required', 'required'));
                // Uncheck saved addresses
                addressRadios.forEach(radio => radio.checked = false);
                updateAddressSelection();
            } else {
                billingDetailsSection.classList.add('d-none');
                billingFields.forEach(field => field.removeAttribute('required'));
                // Check default address
                const defaultRadio = document.querySelector('.address-radio[checked]');
                if (defaultRadio) {
                    defaultRadio.checked = true;
                    loadAddressData(defaultRadio.value);
                }
            }
        });
    }

    // Ship to different address toggle
    const shipToDifferentCheckbox = document.getElementById('ship_to_different');
    const shippingFields = document.querySelector('.ship-to-different .single-form-row');
    const shippingInputs = document.querySelectorAll('.shipping-field');

    if (shipToDifferentCheckbox) {
        shipToDifferentCheckbox.addEventListener('change', function() {
            if (this.checked) {
                shippingFields.style.display = 'block';
                shippingInputs.forEach(input => input.setAttribute('required', 'required'));
            } else {
                shippingFields.style.display = 'none';
                shippingInputs.forEach(input => input.removeAttribute('required'));
            }
        });
    }

    // Initialize
    updateAddressSelection();

    // Payment method selection
    const paymentHeaders = document.querySelectorAll('#accordion .card-header');
    const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
    
    // Add visual feedback class
    function updatePaymentSelection() {
        paymentHeaders.forEach(header => {
            header.classList.remove('selected');
        });
        
        const selectedRadio = document.querySelector('input[name="payment_method"]:checked');
        if (selectedRadio) {
            const selectedHeader = document.querySelector(`[data-payment="${selectedRadio.id}"]`);
            if (selectedHeader) {
                selectedHeader.classList.add('selected');
            }
        }
    }
    
    paymentHeaders.forEach(header => {
        header.addEventListener('click', function(e) {
            // Don't trigger if clicking on a link
            if (e.target.tagName === 'A') return;
            
            const paymentId = this.getAttribute('data-payment');
            const radio = document.getElementById(paymentId);
            
            if (radio) {
                // Uncheck all radio buttons first
                paymentRadios.forEach(r => {
                    r.checked = false;
                });
                
                // Select the radio button
                radio.checked = true;
                
                // Trigger change event to ensure form recognizes it
                radio.dispatchEvent(new Event('change', { bubbles: true }));
                
                updatePaymentSelection();
                
                console.log('Payment method selected:', radio.value);
            }
        });
    });

    // Update visual selection on load
    updatePaymentSelection();

    // Form submission validation
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            const selectedPayment = document.querySelector('input[name="payment_method"]:checked');
            
            if (!selectedPayment) {
                e.preventDefault();
                e.stopPropagation();
                alert('Please select a payment method');
                
                // Scroll to payment section
                const paymentSection = document.querySelector('.shop-payment-method');
                if (paymentSection) {
                    paymentSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    paymentSection.style.border = '2px solid red';
                    setTimeout(() => {
                        paymentSection.style.border = '';
                    }, 2000);
                }
                
                return false;
            }
            
            console.log('Submitting with payment method:', selectedPayment.value);
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/pages/shop-checkout.blade.php ENDPATH**/ ?>