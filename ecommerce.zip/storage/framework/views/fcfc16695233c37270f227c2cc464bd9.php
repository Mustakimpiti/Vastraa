

<?php $__env->startSection('title', 'Manage Contact Messages'); ?>
<?php $__env->startSection('page-title', 'Contact Messages'); ?>

<?php $__env->startSection('content'); ?>


<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" style="position: relative; z-index: 9999;">
        <strong>✅ Success!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="position: relative; z-index: 9999;">
        <strong>❌ Error!</strong> <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="position: relative; z-index: 9999;">
        <strong>❌ Validation Errors:</strong>
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">All Contact Messages</h5>
        <div>
            <!-- Filter Buttons -->
            <a href="<?php echo e(route('admin.contacts.index')); ?>" 
               class="btn btn-sm <?php echo e(!request('status') ? 'btn-primary' : 'btn-outline-primary'); ?>">
                All (<?php echo e(\App\Models\Contact::count()); ?>)
            </a>
            <a href="<?php echo e(route('admin.contacts.index', ['status' => 'unread'])); ?>" 
               class="btn btn-sm <?php echo e(request('status') == 'unread' ? 'btn-danger' : 'btn-outline-danger'); ?>">
                Unread (<?php echo e(\App\Models\Contact::where('status', 'unread')->count()); ?>)
            </a>
            <a href="<?php echo e(route('admin.contacts.index', ['status' => 'read'])); ?>" 
               class="btn btn-sm <?php echo e(request('status') == 'read' ? 'btn-warning' : 'btn-outline-warning'); ?>">
                Read (<?php echo e(\App\Models\Contact::where('status', 'read')->count()); ?>)
            </a>
            <a href="<?php echo e(route('admin.contacts.index', ['status' => 'replied'])); ?>" 
               class="btn btn-sm <?php echo e(request('status') == 'replied' ? 'btn-success' : 'btn-outline-success'); ?>">
                Replied (<?php echo e(\App\Models\Contact::where('status', 'replied')->count()); ?>)
            </a>
        </div>
    </div>
    
    <!-- Search Bar -->
    <div class="card-body border-bottom">
        <form action="<?php echo e(route('admin.contacts.index')); ?>" method="GET" class="row g-3">
            <?php if(request('status')): ?>
                <input type="hidden" name="status" value="<?php echo e(request('status')); ?>">
            <?php endif; ?>
            <div class="col-md-10">
                <input type="text" 
                       name="search" 
                       class="form-control" 
                       placeholder="Search by name, email, phone, or message..." 
                       value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fa fa-search"></i> Search
                </button>
            </div>
        </form>
    </div>

    <div class="card-body">
        <?php if($contacts->count() > 0): ?>
        <!-- Bulk Actions -->
        <div class="mb-3">
            <form action="<?php echo e(route('admin.contacts.bulk-action')); ?>" method="POST" id="bulk-action-form">
                <?php echo csrf_field(); ?>
                <div class="row align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Bulk Actions</label>
                        <select name="action" class="form-select" required>
                            <option value="">Select Action</option>
                            <option value="mark_read">Mark as Read</option>
                            <option value="mark_replied">Mark as Replied</option>
                            <option value="delete">Delete</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-secondary w-100" 
                                onclick="return confirm('Are you sure you want to perform this action?')">
                            Apply
                        </button>
                    </div>
                    <div class="col-md-7 text-end">
                        <small class="text-muted">
                            <span id="selected-count">0</span> message(s) selected
                        </small>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th style="width: 40px;">
                            <input type="checkbox" id="select-all" class="form-check-input">
                        </th>
                        <th>Customer</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($contact->status == 'unread' ? 'table-warning' : ''); ?>">
                        <td>
                            <input type="checkbox" 
                                   name="contact_ids[]" 
                                   value="<?php echo e($contact->id); ?>" 
                                   class="form-check-input contact-checkbox"
                                   form="bulk-action-form">
                        </td>
                        <td>
                            <div>
                                <strong><?php echo e($contact->name); ?></strong>
                                <?php if($contact->status == 'unread'): ?>
                                    <span class="badge bg-danger ms-2" style="font-size: 10px;">NEW</span>
                                <?php endif; ?>
                            </div>
                            <small class="text-muted"><?php echo e($contact->email); ?></small><br>
                            <?php if($contact->phone): ?>
                                <small class="text-muted">
                                    <i class="fa fa-phone"></i> <?php echo e($contact->phone); ?>

                                </small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="max-width: 300px;">
                                <?php echo e(Str::limit($contact->message, 100)); ?>

                                <?php if(strlen($contact->message) > 100): ?>
                                    <a href="#" 
                                       data-bs-toggle="modal" 
                                       data-bs-target="#contactModal<?php echo e($contact->id); ?>"
                                       onclick="markAsRead(<?php echo e($contact->id); ?>)">
                                        <small>Read more</small>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <small><?php echo e($contact->created_at->format('M d, Y')); ?></small><br>
                            <small class="text-muted"><?php echo e($contact->created_at->format('h:i A')); ?></small>
                            <?php if($contact->replied_at): ?>
                                <br><small class="text-success">
                                    <i class="fa fa-reply"></i> Replied: <?php echo e($contact->replied_at->format('M d')); ?>

                                </small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($contact->status == 'unread'): ?>
                                <span class="badge bg-danger">Unread</span>
                            <?php elseif($contact->status == 'read'): ?>
                                <span class="badge bg-warning">Read</span>
                            <?php elseif($contact->status == 'replied'): ?>
                                <span class="badge bg-success">Replied</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <button type="button" 
                                        class="btn btn-sm btn-info btn-action" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#contactModal<?php echo e($contact->id); ?>"
                                        onclick="markAsRead(<?php echo e($contact->id); ?>)"
                                        title="View Details">
                                    <i class="fa fa-eye"></i>
                                </button>
                                
                                <?php if($contact->status != 'replied'): ?>
                                <button type="button" 
                                        class="btn btn-sm btn-success btn-action" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#replyModal<?php echo e($contact->id); ?>"
                                        title="Reply">
                                    <i class="fa fa-reply"></i>
                                </button>
                                <?php endif; ?>
                                
                                <?php if($contact->status == 'unread'): ?>
                                <form action="<?php echo e(route('admin.contacts.mark-read', $contact->id)); ?>" 
                                      method="POST" 
                                      class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-warning btn-action" 
                                            title="Mark as Read">
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>
                                <?php else: ?>
                                <form action="<?php echo e(route('admin.contacts.mark-unread', $contact->id)); ?>" 
                                      method="POST" 
                                      class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-secondary btn-action" 
                                            title="Mark as Unread">
                                        <i class="fa fa-envelope"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                                
                                <form action="<?php echo e(route('admin.contacts.destroy', $contact->id)); ?>" 
                                      method="POST" 
                                      class="d-inline" 
                                      onsubmit="return confirm('Are you sure you want to delete this message?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-danger btn-action" 
                                            title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

                    <!-- Contact Details Modal -->
                    <div class="modal fade" id="contactModal<?php echo e($contact->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Contact Message Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <strong>Name:</strong> <?php echo e($contact->name); ?>

                                    </div>
                                    <div class="mb-3">
                                        <strong>Email:</strong> 
                                        <a href="mailto:<?php echo e($contact->email); ?>"><?php echo e($contact->email); ?></a>
                                    </div>
                                    <?php if($contact->phone): ?>
                                    <div class="mb-3">
                                        <strong>Phone:</strong> 
                                        <a href="tel:<?php echo e($contact->phone); ?>"><?php echo e($contact->phone); ?></a>
                                    </div>
                                    <?php endif; ?>
                                    <div class="mb-3">
                                        <strong>Message:</strong>
                                        <div class="mt-2 p-3 bg-light rounded">
                                            <?php echo e($contact->message); ?>

                                        </div>
                                    </div>
                                    
                                    <?php if($contact->admin_reply): ?>
                                    <div class="mb-3">
                                        <strong>Your Reply:</strong>
                                        <div class="mt-2 p-3 bg-success bg-opacity-10 rounded border border-success">
                                            <?php echo e($contact->admin_reply); ?>

                                        </div>
                                        <small class="text-muted">
                                            Replied on: <?php echo e($contact->replied_at->format('F d, Y h:i A')); ?>

                                        </small>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="mb-3">
                                        <strong>Received:</strong> <?php echo e($contact->created_at->format('F d, Y h:i A')); ?>

                                    </div>
                                    <div>
                                        <strong>Status:</strong>
                                        <?php if($contact->status == 'unread'): ?>
                                            <span class="badge bg-danger">Unread</span>
                                        <?php elseif($contact->status == 'read'): ?>
                                            <span class="badge bg-warning">Read</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Replied</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <?php if($contact->status != 'replied'): ?>
                                    <button type="button" 
                                            class="btn btn-success" 
                                            data-bs-dismiss="modal"
                                            data-bs-toggle="modal" 
                                            data-bs-target="#replyModal<?php echo e($contact->id); ?>">
                                        <i class="fa fa-reply"></i> Reply to Customer
                                    </button>
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reply Modal -->
                    <div class="modal fade" id="replyModal<?php echo e($contact->id); ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <form action="<?php echo e(route('admin.contacts.reply', $contact->id)); ?>" 
                                      method="POST" 
                                      id="replyForm<?php echo e($contact->id); ?>"
                                      onsubmit="console.log('Form submitting for contact <?php echo e($contact->id); ?>'); return true;">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title">Reply to <?php echo e($contact->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <strong>Customer's Message:</strong>
                                            <div class="mt-2 p-3 bg-light rounded">
                                                <?php echo e($contact->message); ?>

                                            </div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="admin_reply<?php echo e($contact->id); ?>" class="form-label">
                                                <strong>Your Reply:</strong>
                                            </label>
                                            <textarea class="form-control" 
                                                      id="admin_reply<?php echo e($contact->id); ?>"
                                                      name="admin_reply" 
                                                      rows="6" 
                                                      required
                                                      minlength="10"
                                                      placeholder="Type your response here (minimum 10 characters)..."></textarea>
                                            <small class="text-muted">
                                                This reply will be sent to <?php echo e($contact->email); ?>

                                            </small>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-success" id="sendBtn<?php echo e($contact->id); ?>">
                                            <i class="fa fa-paper-plane"></i> Send Reply
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($contacts->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fa fa-envelope fa-3x text-muted mb-3"></i>
            <p class="text-muted">
                <?php if(request('search')): ?>
                    No contact messages found matching your search.
                <?php else: ?>
                    No contact messages found yet. Messages will appear here when customers contact you!
                <?php endif; ?>
            </p>
            <?php if(request('search') || request('status')): ?>
                <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-primary">Clear Filters</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Quick Stats Card -->
<div class="row mt-4">
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3><?php echo e(\App\Models\Contact::count()); ?></h3>
                <p class="text-muted mb-0">Total Messages</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-danger"><?php echo e(\App\Models\Contact::where('status', 'unread')->count()); ?></h3>
                <p class="text-muted mb-0">Unread</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-warning"><?php echo e(\App\Models\Contact::where('status', 'read')->count()); ?></h3>
                <p class="text-muted mb-0">Read</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-success"><?php echo e(\App\Models\Contact::where('status', 'replied')->count()); ?></h3>
                <p class="text-muted mb-0">Replied</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.btn-action {
    margin: 0 2px;
}
.modal-body strong {
    color: #2c3e50;
}
.table-warning {
    background-color: #fff3cd !important;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
console.log('Contact management page loaded');

// Select All Checkbox
document.getElementById('select-all').addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.contact-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
    });
    updateSelectedCount();
});

// Update selected count
document.querySelectorAll('.contact-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', updateSelectedCount);
});

function updateSelectedCount() {
    const selected = document.querySelectorAll('.contact-checkbox:checked').length;
    document.getElementById('selected-count').textContent = selected;
}

// Mark as read via AJAX when viewing details
function markAsRead(contactId) {
    console.log('Marking contact as read:', contactId);
    fetch(`/admin/contacts/${contactId}/mark-read`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Content-Type': 'application/json'
        }
    }).then(response => {
        console.log('Mark as read response:', response.status);
    }).catch(error => {
        console.error('Mark as read error:', error);
    });
}

// Initialize count on page load
updateSelectedCount();

// Debug: Log all reply forms
document.querySelectorAll('[id^="replyForm"]').forEach(form => {
    console.log('Found reply form:', form.id);
    form.addEventListener('submit', function(e) {
        console.log('Reply form submitted:', form.id);
        const textarea = form.querySelector('textarea[name="admin_reply"]');
        console.log('Reply content:', textarea.value);
        console.log('Reply length:', textarea.value.length);
        
        if (textarea.value.length < 10) {
            e.preventDefault();
            alert('Please enter at least 10 characters in your reply.');
            return false;
        }
    });
});

// Scroll to top on page load if there's a success/error message
window.addEventListener('load', function() {
    if (document.querySelector('.alert')) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/contacts/index.blade.php ENDPATH**/ ?>