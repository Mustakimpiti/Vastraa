<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></title>

    <!--== Bootstrap CSS ==-->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!--== Font-awesome Icons CSS ==-->
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
    
    <style>
        .admin-sidebar {
            min-height: 100vh;
            background: #2c3e50;
            color: white;
        }
        .admin-sidebar .nav-link {
            color: #ecf0f1;
            padding: 12px 20px;
            border-radius: 4px;
            margin: 5px 10px;
            transition: all 0.3s ease;
        }
        .admin-sidebar .nav-link:hover,
        .admin-sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .admin-sidebar .nav-link i {
            margin-right: 8px;
            width: 20px;
        }
        .admin-content {
            padding: 30px;
        }
        .admin-header {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .btn-action {
            margin: 0 3px;
        }
        .saree-img-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            font-weight: 600;
            margin-bottom: 8px;
        }
        .alert {
            margin-bottom: 20px;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 4px;
        }
        .pending-badge {
            background: #f39c12;
            color: white;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 10px;
            margin-left: 5px;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-md-block admin-sidebar">
                <div class="p-3">
                    <h4 class="text-center mb-4">Admin Panel</h4>
<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/collections*') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.collections.index')); ?>">
            <i class="fa fa-folder-open"></i> Collections
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/sarees*') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.sarees.index')); ?>">
            <i class="fa fa-shopping-bag"></i> Sarees
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/reviews*') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.reviews.index')); ?>">
            <i class="fa fa-star"></i> Reviews
            <?php
                $pendingCount = \App\Models\Review::where('is_approved', false)->count();
            ?>
            <?php if($pendingCount > 0): ?>
                <span class="pending-badge"><?php echo e($pendingCount); ?></span>
            <?php endif; ?>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/contacts*') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.contacts.index')); ?>">
            <i class="fa fa-envelope"></i> Contacts
            <?php
                $unreadCount = \App\Models\Contact::where('status', 'unread')->count();
            ?>
            <?php if($unreadCount > 0): ?>
                <span class="pending-badge"><?php echo e($unreadCount); ?></span>
            <?php endif; ?>
        </a>
    </li>
<li class="nav-item">
    <a class="nav-link <?php echo e(Request::is('admin/users*') ? 'active' : ''); ?>" 
       href="<?php echo e(route('admin.users.index')); ?>">
        <i class="fa fa-users"></i> Users
    </a>
</li>
    <li class="nav-item">
        <a class="nav-link <?php echo e(Request::is('admin/orders*') ? 'active' : ''); ?>" 
           href="<?php echo e(route('admin.orders.index')); ?>">
            <i class="fa fa-shopping-cart"></i> Orders
            <?php
                $pendingOrders = \App\Models\Order::where('order_status', 'pending')->count();
            ?>
            <?php if($pendingOrders > 0): ?>
                <span class="pending-badge"><?php echo e($pendingOrders); ?></span>
            <?php endif; ?>
        </a>
    </li>
<li class="nav-item">
    <a class="nav-link <?php echo e(Request::is('admin/contact-settings*') ? 'active' : ''); ?>" 
       href="<?php echo e(route('admin.contact-settings.index')); ?>">
        <i class="fa fa-cog"></i> Contact Settings
    </a>
</li>
    <li class="nav-item mt-4">
        <a class="nav-link" href="<?php echo e(route('home')); ?>" target="_blank">
            <i class="fa fa-external-link"></i> View Site
        </a>
    </li>
</ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto">
                <div class="admin-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h3>
                        <div>
                            <span class="me-3">Welcome, <?php echo e(Auth::user()->name ?? 'Admin'); ?></span>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Logout</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="admin-content">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
    </div>

    <!--== Scripts ==-->
    <script src="<?php echo e(asset('assets/js/jquery-main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>