

<?php $__env->startSection('title', 'Manage Collections'); ?>
<?php $__env->startSection('page-title', 'Manage Collections'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">All Collections</h5>
        <a href="<?php echo e(route('admin.collections.create')); ?>" class="btn btn-primary">
            <i class="fa fa-plus"></i> Add New Collection
        </a>
    </div>
    <div class="card-body">
        <?php if($collections->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Sarees Count</th>
                        <th>Sort Order</th>
                        <th>Launch Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($collection->image): ?>
                                <img src="<?php echo e(asset($collection->image)); ?>" 
                                     alt="<?php echo e($collection->name); ?>" 
                                     class="saree-img-thumb">
                            <?php else: ?>
                                <div class="saree-img-thumb bg-secondary d-flex align-items-center justify-content-center">
                                    <i class="fa fa-image text-white"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?php echo e($collection->name); ?></strong><br>
                            <?php if($collection->description): ?>
                                <small class="text-muted"><?php echo e(Str::limit($collection->description, 50)); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo e($collection->sarees_count); ?> <?php echo e(Str::plural('Saree', $collection->sarees_count)); ?></span>
                        </td>
                        <td><?php echo e($collection->sort_order ?? '-'); ?></td>
                        <td>
                            <?php if($collection->launch_date): ?>
                                <?php echo e($collection->launch_date->format('M d, Y')); ?>

                                <?php if($collection->launch_date->isFuture()): ?>
                                    <br><small class="badge bg-warning">Coming Soon</small>
                                <?php elseif($collection->launch_date->isToday()): ?>
                                    <br><small class="badge bg-success">Launching Today</small>
                                <?php endif; ?>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($collection->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.collections.show', $collection)); ?>" 
                               class="btn btn-sm btn-info btn-action" 
                               title="View">
                                <i class="fa fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('admin.collections.edit', $collection)); ?>" 
                               class="btn btn-sm btn-warning btn-action" 
                               title="Edit">
                                <i class="fa fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.collections.destroy', $collection)); ?>" 
                                  method="POST" 
                                  class="d-inline"
                                  onsubmit="return confirm('Are you sure you want to delete this collection?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" 
                                        class="btn btn-sm btn-danger btn-action" 
                                        title="Delete">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($collections->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fa fa-folder-open fa-3x text-muted mb-3"></i>
            <p class="text-muted">No collections found. Add your first collection to get started!</p>
            <a href="<?php echo e(route('admin.collections.create')); ?>" class="btn btn-primary">
                <i class="fa fa-plus"></i> Add New Collection
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/collections/index.blade.php ENDPATH**/ ?>