

<?php $__env->startSection('title', 'Manage Users'); ?>
<?php $__env->startSection('page-title', 'Manage Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-white">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
            <h5 class="mb-0">All Users</h5>
            <div class="d-flex flex-wrap gap-2">
                <!-- Filter Buttons -->
                <a href="<?php echo e(route('admin.users.index')); ?>" 
                   class="btn btn-sm <?php echo e(!request('role') ? 'btn-primary' : 'btn-outline-primary'); ?>">
                    All (<?php echo e(\App\Models\User::count()); ?>)
                </a>
                <a href="<?php echo e(route('admin.users.index', ['role' => 'admin'])); ?>" 
                   class="btn btn-sm <?php echo e(request('role') == 'admin' ? 'btn-danger' : 'btn-outline-danger'); ?>">
                    Admins (<?php echo e(\App\Models\User::where('role', 'admin')->count()); ?>)
                </a>
                <a href="<?php echo e(route('admin.users.index', ['role' => 'customer'])); ?>" 
                   class="btn btn-sm <?php echo e(request('role') == 'customer' ? 'btn-success' : 'btn-outline-success'); ?>">
                    Customers (<?php echo e(\App\Models\User::where('role', 'customer')->count()); ?>)
                </a>
                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                    <i class="fa fa-plus"></i> <span class="d-none d-sm-inline">Add New</span>
                </button>
            </div>
        </div>
    </div>
    
    <!-- Search Bar -->
    <div class="card-body border-bottom">
        <form action="<?php echo e(route('admin.users.index')); ?>" method="GET" class="row g-2">
            <div class="col-12 col-md-10">
                <input type="text" 
                       name="search" 
                       class="form-control" 
                       placeholder="Search by name or email..." 
                       value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-12 col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fa fa-search"></i> Search
                </button>
            </div>
        </form>
    </div>

    <div class="card-body p-0">
        <?php if($users->count() > 0): ?>
        <!-- Desktop Table View -->
        <div class="table-responsive d-none d-lg-block">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Joined</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle">#<?php echo e($user->id); ?></td>
                        <td class="align-middle">
                            <div class="d-flex align-items-center">
                                <div class="user-avatar me-2">
                                    <div class="avatar-circle">
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    </div>
                                </div>
                                <strong><?php echo e($user->name); ?></strong>
                            </div>
                        </td>
                        <td class="align-middle"><?php echo e($user->email); ?></td>
                        <td class="align-middle">
                            <?php if($user->role === 'admin'): ?>
                                <span class="badge bg-danger">Admin</span>
                            <?php else: ?>
                                <span class="badge bg-success">Customer</span>
                            <?php endif; ?>
                        </td>
                        <td class="align-middle">
                            <small><?php echo e($user->created_at->format('M d, Y')); ?></small>
                        </td>
                        <td class="align-middle text-end">
                            <div class="btn-group" role="group">
                                <button class="btn btn-sm btn-info" 
                                        title="View Details"
                                        data-bs-toggle="modal" 
                                        data-bs-target="#userModal<?php echo e($user->id); ?>">
                                    <i class="fa fa-eye"></i>
                                </button>
                                
                                <button class="btn btn-sm btn-primary" 
                                        title="Edit User"
                                        data-bs-toggle="modal" 
                                        data-bs-target="#editUserModal<?php echo e($user->id); ?>">
                                    <i class="fa fa-edit"></i>
                                </button>
                                
                                <?php if(Auth::id() !== $user->id): ?>
                                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" 
                                      method="POST" 
                                      class="d-inline" 
                                      onsubmit="return confirm('Are you sure you want to delete this user? This will also delete all their orders, reviews, and cart items.')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-danger" 
                                            title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                                <?php else: ?>
                                <button class="btn btn-sm btn-secondary" 
                                        title="Cannot delete yourself" 
                                        disabled>
                                    <i class="fa fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Mobile Card View -->
        <div class="d-lg-none">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="user-card p-3 border-bottom">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div class="d-flex align-items-center flex-grow-1">
                        <div class="avatar-circle me-3">
                            <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                        </div>
                        <div>
                            <h6 class="mb-0"><?php echo e($user->name); ?></h6>
                            <small class="text-muted"><?php echo e($user->email); ?></small>
                        </div>
                    </div>
                    <?php if($user->role === 'admin'): ?>
                        <span class="badge bg-danger">Admin</span>
                    <?php else: ?>
                        <span class="badge bg-success">Customer</span>
                    <?php endif; ?>
                </div>
                
                <div class="row g-2 mb-3 small">
                    <div class="col-6">
                        <strong>ID:</strong> #<?php echo e($user->id); ?>

                    </div>
                    <div class="col-6">
                        <strong>Joined:</strong> <?php echo e($user->created_at->format('M d, Y')); ?>

                    </div>
                </div>

                <div class="d-flex gap-2 justify-content-end">
                    <button class="btn btn-sm btn-info" 
                            data-bs-toggle="modal" 
                            data-bs-target="#userModal<?php echo e($user->id); ?>">
                        <i class="fa fa-eye"></i> View
                    </button>
                    
                    <button class="btn btn-sm btn-primary" 
                            data-bs-toggle="modal" 
                            data-bs-target="#editUserModal<?php echo e($user->id); ?>">
                        <i class="fa fa-edit"></i> Edit
                    </button>
                    
                    <?php if(Auth::id() !== $user->id): ?>
                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" 
                          method="POST" 
                          class="d-inline" 
                          onsubmit="return confirm('Are you sure you want to delete this user?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fa fa-trash"></i>
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="p-3">
            <?php echo e($users->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-5">
            <i class="fa fa-users fa-3x text-muted mb-3"></i>
            <p class="text-muted">
                <?php if(request('search')): ?>
                    No users found matching your search.
                <?php else: ?>
                    No users found yet.
                <?php endif; ?>
            </p>
            <?php if(request('search') || request('role')): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">Clear Filters</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- User Details Modals (Outside the table loop) -->
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- User Details Modal -->
<div class="modal fade" id="userModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fa fa-user-circle"></i> User Details - <?php echo e($user->name); ?>

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- User Info Section -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title mb-3"><i class="fa fa-info-circle"></i> Personal Information</h6>
                                <div class="mb-2">
                                    <strong>Name:</strong> <?php echo e($user->name); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Email:</strong> <?php echo e($user->email); ?>

                                </div>
                                <div class="mb-2">
                                    <strong>Role:</strong>
                                    <?php if($user->role === 'admin'): ?>
                                        <span class="badge bg-danger">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Customer</span>
                                    <?php endif; ?>
                                </div>
                                <div class="mb-2">
                                    <strong>Joined:</strong> <?php echo e($user->created_at->format('F d, Y h:i A')); ?>

                                </div>
                                <div>
                                    <strong>Member for:</strong> <?php echo e($user->created_at->diffForHumans()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body">
                                <h6 class="card-title mb-3"><i class="fa fa-chart-bar"></i> Activity Statistics</h6>
                                <div class="mb-2">
                                    <strong>Total Orders:</strong> 
                                    <span class="badge bg-primary"><?php echo e($user->orders->count()); ?></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Total Spent:</strong> 
                                    <span class="text-success fw-bold">₹<?php echo e(number_format($user->orders->sum('total'), 2)); ?></span>
                                </div>
                                <div class="mb-2">
                                    <strong>Reviews Written:</strong> 
                                    <span class="badge bg-warning"><?php echo e($user->reviews->count()); ?></span>
                                </div>
                                <div>
                                    <strong>Wishlist Items:</strong> 
                                    <span class="badge bg-info"><?php echo e($user->wishlists->count()); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Orders Section -->
                <?php if($user->orders->count() > 0): ?>
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0"><i class="fa fa-shopping-cart"></i> Order History (<?php echo e($user->orders->count()); ?> orders)</h6>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Order Number</th>
                                        <th>Date</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $user->orders->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle">
                                            <strong><?php echo e($order->order_number); ?></strong>
                                        </td>
                                        <td class="align-middle">
                                            <?php echo e($order->created_at->format('M d, Y')); ?><br>
                                            <small class="text-muted"><?php echo e($order->created_at->format('h:i A')); ?></small>
                                        </td>
                                        <td class="align-middle"><?php echo e($order->items->count()); ?> items</td>
                                        <td class="align-middle">
                                            <strong class="text-success">₹<?php echo e(number_format($order->total, 2)); ?></strong>
                                        </td>
                                        <td class="align-middle">
                                            <span class="badge bg-<?php echo e($order->getPaymentBadgeClass()); ?>">
                                                <?php echo e(ucfirst($order->payment_status)); ?>

                                            </span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="badge bg-<?php echo e($order->getStatusBadgeClass()); ?>">
                                                <?php echo e(ucfirst($order->order_status)); ?>

                                            </span>
                                        </td>
                                        <td class="align-middle">
                                            <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" 
                                               class="btn btn-sm btn-outline-primary" 
                                               target="_blank">
                                                <i class="fa fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    <i class="fa fa-info-circle"></i> This user hasn't placed any orders yet.
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <?php if($user->orders->count() > 0): ?>
                <a href="<?php echo e(route('admin.orders.index', ['user_id' => $user->id])); ?>" 
                   class="btn btn-primary"
                   target="_blank">
                    <i class="fa fa-shopping-cart"></i> View All Orders in Orders Page
                </a>
                <?php endif; ?>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" 
                               value="<?php echo e($user->name); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?php echo e($user->email); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-control" required>
                            <option value="customer" <?php echo e($user->role === 'customer' ? 'selected' : ''); ?>>Customer</option>
                            <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password (leave blank to keep current)</label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Enter new password (optional)">
                        <small class="text-muted">Only fill this if you want to change the password</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-save"></i> Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Add User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add New User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-control" required>
                            <option value="customer">Customer</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-plus"></i> Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Quick Stats Card -->
<div class="row mt-4 g-3">
    <div class="col-6 col-md-3">
        <div class="card text-center h-100">
            <div class="card-body">
                <h3 class="mb-1"><?php echo e(\App\Models\User::count()); ?></h3>
                <p class="text-muted mb-0 small">Total Users</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card text-center h-100">
            <div class="card-body">
                <h3 class="text-danger mb-1"><?php echo e(\App\Models\User::where('role', 'admin')->count()); ?></h3>
                <p class="text-muted mb-0 small">Admins</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card text-center h-100">
            <div class="card-body">
                <h3 class="text-success mb-1"><?php echo e(\App\Models\User::where('role', 'customer')->count()); ?></h3>
                <p class="text-muted mb-0 small">Customers</p>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card text-center h-100">
            <div class="card-body">
                <h3 class="text-info mb-1"><?php echo e(\App\Models\User::whereDate('created_at', '>=', now()->subDays(30))->count()); ?></h3>
                <p class="text-muted mb-0 small">New This Month</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.avatar-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
    flex-shrink: 0;
}

.modal-body strong {
    color: #2c3e50;
}

.user-card {
    transition: background-color 0.2s;
}

.user-card:hover {
    background-color: #f8f9fa;
}

/* Modal size */
.modal-xl {
    max-width: 1200px;
}

/* Responsive adjustments */
@media (max-width: 991.98px) {
    .avatar-circle {
        width: 35px;
        height: 35px;
        font-size: 16px;
    }
    
    .modal-xl {
        max-width: 95%;
    }
}

@media (max-width: 575.98px) {
    .card-header h5 {
        font-size: 1rem;
    }
    
    .btn-sm {
        font-size: 0.8rem;
        padding: 0.25rem 0.5rem;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/users/index.blade.php ENDPATH**/ ?>