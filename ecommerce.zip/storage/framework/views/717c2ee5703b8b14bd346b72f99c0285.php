

<?php $__env->startSection('title', 'Add New Saree'); ?>
<?php $__env->startSection('page-title', 'Add New Saree'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <a href="<?php echo e(route('admin.sarees.index')); ?>" class="btn btn-secondary mb-3">
            <i class="fa fa-arrow-left"></i> Back to List
        </a>
    </div>
</div>

<form action="<?php echo e(route('admin.sarees.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    
    <div class="row">
        <!-- Main Information -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Basic Information</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="name" class="form-label">Saree Name *</label>
                        <input type="text" 
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="name" 
                               name="name" 
                               value="<?php echo e(old('name')); ?>" 
                               required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="sku" class="form-label">SKU *</label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="sku" 
                                       name="sku" 
                                       value="<?php echo e(old('sku')); ?>" 
                                       required>
                                <small class="text-muted">Unique product identifier</small>
                                <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="fabric" class="form-label">Fabric *</label>
                                <input type="text" 
                                       class="form-control <?php $__errorArgs = ['fabric'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="fabric" 
                                       name="fabric" 
                                       value="<?php echo e(old('fabric')); ?>" 
                                       placeholder="e.g., Silk, Cotton, Georgette"
                                       required>
                                <?php $__errorArgs = ['fabric'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="short_description" class="form-label">Short Description</label>
                        <textarea class="form-control <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="short_description" 
                                  name="short_description" 
                                  rows="2"
                                  placeholder="Brief description for product listing"><?php echo e(old('short_description')); ?></textarea>
                        <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="description" class="form-label">Full Description</label>
                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="description" 
                                  name="description" 
                                  rows="5"
                                  placeholder="Detailed product description"><?php echo e(old('description')); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Saree Details -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Saree Details</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="length" class="form-label">Length (meters)</label>
                                <input type="number" 
                                       step="0.1" 
                                       class="form-control <?php $__errorArgs = ['length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="length" 
                                       name="length" 
                                       value="<?php echo e(old('length', 6.3)); ?>"
                                       placeholder="6.3">
                                <?php $__errorArgs = ['length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="blouse_length" class="form-label">Blouse Length (meters)</label>
                                <input type="number" 
                                       step="0.1" 
                                       class="form-control <?php $__errorArgs = ['blouse_length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="blouse_length" 
                                       name="blouse_length" 
                                       value="<?php echo e(old('blouse_length', 0.8)); ?>"
                                       placeholder="0.8">
                                <?php $__errorArgs = ['blouse_length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label">Blouse Included</label>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" 
                                           type="checkbox" 
                                           id="blouse_included" 
                                           name="blouse_included" 
                                           value="1" 
                                           <?php echo e(old('blouse_included') ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="blouse_included">
                                        Yes, blouse piece included
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="work_type" class="form-label">Work Type</label>
                                <input type="text" 
                                       class="form-control" 
                                       id="work_type" 
                                       name="work_type" 
                                       value="<?php echo e(old('work_type')); ?>" 
                                       placeholder="e.g., Embroidery, Zari, Handloom">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="occasion" class="form-label">Occasion</label>
                                <input type="text" 
                                       class="form-control" 
                                       id="occasion" 
                                       name="occasion" 
                                       value="<?php echo e(old('occasion')); ?>" 
                                       placeholder="e.g., Wedding, Party, Casual">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="pattern" class="form-label">Pattern</label>
                                <input type="text" 
                                       class="form-control" 
                                       id="pattern" 
                                       name="pattern" 
                                       value="<?php echo e(old('pattern')); ?>" 
                                       placeholder="e.g., Floral, Geometric, Plain">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-md-4">
            <!-- Pricing & Stock -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Pricing & Stock</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="price" class="form-label">Regular Price (₹) *</label>
                        <input type="number" 
                               step="0.01" 
                               class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="price" 
                               name="price" 
                               value="<?php echo e(old('price')); ?>" 
                               placeholder="0.00"
                               required>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="sale_price" class="form-label">Sale Price (₹)</label>
                        <input type="number" 
                               step="0.01" 
                               class="form-control <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="sale_price" 
                               name="sale_price" 
                               value="<?php echo e(old('sale_price')); ?>"
                               placeholder="0.00">
                        <small class="text-muted">Leave empty if no discount</small>
                        <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="stock_quantity" class="form-label">Stock Quantity *</label>
                        <input type="number" 
                               class="form-control <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="stock_quantity" 
                               name="stock_quantity" 
                               value="<?php echo e(old('stock_quantity', 0)); ?>" 
                               placeholder="0"
                               required>
                        <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Collection -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Collection</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="collection_id" class="form-label">Select Collection</label>
                        <select class="form-control <?php $__errorArgs = ['collection_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="collection_id" 
                                name="collection_id">
                            <option value="">No Collection</option>
                            <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($collection->id); ?>" 
                                        <?php echo e(old('collection_id') == $collection->id ? 'selected' : ''); ?>>
                                    <?php echo e($collection->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['collection_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <!-- Product Images -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Product Images</h5>
                </div>
                <div class="card-body">
                    <!-- Featured Image -->
                    <div class="form-group mb-4">
                        <label for="featured_image" class="form-label">
                            <strong>Featured Image (Main) *</strong>
                        </label>
                        <input type="file" 
                               class="form-control <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="featured_image" 
                               name="featured_image" 
                               accept="image/jpeg,image/png,image/jpg,image/gif">
                        <small class="text-muted">This will be the main product image (Max: 2MB)</small>
                        <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div id="featured-preview" class="mt-2"></div>
                    </div>

                    <hr>

                    <!-- Additional Images -->
                    <div class="form-group">
                        <label for="additional_images" class="form-label">
                            <strong>Additional Images (Gallery)</strong>
                        </label>
                        <input type="file" 
                               class="form-control <?php $__errorArgs = ['additional_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="additional_images" 
                               name="additional_images[]" 
                               accept="image/jpeg,image/png,image/jpg,image/gif"
                               multiple>
                        <small class="text-muted">Select multiple images (Hold Ctrl/Cmd). Max: 2MB each</small>
                        <?php $__errorArgs = ['additional_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div id="additional-preview" class="mt-3 row"></div>
                    </div>
                </div>
            </div>

            <!-- Status Flags -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Status & Badges</h5>
                </div>
                <div class="card-body">
                    <div class="form-check mb-2">
                        <input class="form-check-input" 
                               type="checkbox" 
                               id="is_active" 
                               name="is_active" 
                               value="1" 
                               <?php echo e(old('is_active', true) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_active">
                            <strong>Active</strong>
                            <small class="d-block text-muted">Visible on website</small>
                        </label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" 
                               type="checkbox" 
                               id="is_featured" 
                               name="is_featured" 
                               value="1" 
                               <?php echo e(old('is_featured') ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_featured">
                            <strong>Featured</strong>
                            <small class="d-block text-muted">Show in featured section</small>
                        </label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" 
                               type="checkbox" 
                               id="is_new_arrival" 
                               name="is_new_arrival" 
                               value="1" 
                               <?php echo e(old('is_new_arrival') ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_new_arrival">
                            <strong>New Arrival</strong>
                            <small class="d-block text-muted">Show "New" badge</small>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" 
                               type="checkbox" 
                               id="is_bestseller" 
                               name="is_bestseller" 
                               value="1" 
                               <?php echo e(old('is_bestseller') ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="is_bestseller">
                            <strong>Bestseller</strong>
                            <small class="d-block text-muted">Show "Bestseller" badge</small>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="card">
                <div class="card-body">
                    <button type="submit" class="btn btn-primary w-100 btn-lg">
                        <i class="fa fa-save"></i> Create Saree
                    </button>
                    <a href="<?php echo e(route('admin.sarees.index')); ?>" class="btn btn-secondary w-100 mt-2">
                        <i class="fa fa-times"></i> Cancel
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>

<?php $__env->startPush('styles'); ?>
<style>
.image-preview-item {
    position: relative;
    margin-bottom: 10px;
}
.image-preview-item img {
    max-height: 150px;
    width: 100%;
    object-fit: cover;
    border-radius: 4px;
    border: 2px solid #e0e0e0;
}
.remove-preview {
    position: absolute;
    top: 5px;
    right: 15px;
    background: #dc3545;
    color: white;
    border: none;
    border-radius: 50%;
    width: 25px;
    height: 25px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    line-height: 1;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}
.remove-preview:hover {
    background: #c82333;
}
.form-group {
    margin-bottom: 1rem;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Featured Image Preview
document.getElementById('featured_image').addEventListener('change', function(e) {
    const preview = document.getElementById('featured-preview');
    const file = e.target.files[0];
    
    if (file) {
        // Validate file size (2MB)
        if (file.size > 2048000) {
            alert('File size should not exceed 2MB');
            this.value = '';
            preview.innerHTML = '';
            return;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = `
                <div class="image-preview-item">
                    <img src="${e.target.result}" class="img-fluid" alt="Featured image preview">
                    <small class="text-success d-block mt-1">
                        <i class="fa fa-check"></i> Image selected successfully
                    </small>
                </div>
            `;
        }
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = '';
    }
});

// Additional Images Preview
document.getElementById('additional_images').addEventListener('change', function(e) {
    const preview = document.getElementById('additional-preview');
    const files = Array.from(e.target.files);
    
    preview.innerHTML = '';
    
    if (files.length > 0) {
        // Validate file sizes
        const oversizedFiles = files.filter(file => file.size > 2048000);
        if (oversizedFiles.length > 0) {
            alert(`${oversizedFiles.length} file(s) exceed 2MB size limit`);
            this.value = '';
            return;
        }
        
        files.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const col = document.createElement('div');
                col.className = 'col-md-4 mb-2';
                col.innerHTML = `
                    <div class="image-preview-item">
                        <img src="${e.target.result}" class="img-fluid" alt="Gallery image ${index + 1}">
                        <span class="badge bg-primary position-absolute" style="top: 5px; left: 15px;">
                            ${index + 1}
                        </span>
                    </div>
                `;
                preview.appendChild(col);
            }
            reader.readAsDataURL(file);
        });
        
        // Add success message
        const successMsg = document.createElement('div');
        successMsg.className = 'col-12';
        successMsg.innerHTML = `
            <small class="text-success">
                <i class="fa fa-check"></i> ${files.length} image(s) selected successfully
            </small>
        `;
        preview.appendChild(successMsg);
    }
});

// Auto-generate SKU from name (optional)
document.getElementById('name').addEventListener('blur', function() {
    const skuField = document.getElementById('sku');
    if (!skuField.value) {
        const sku = this.value
            .toUpperCase()
            .replace(/[^A-Z0-9]/g, '')
            .substring(0, 8) + '-' + Math.floor(Math.random() * 1000);
        skuField.value = sku;
    }
});

// Validate sale price is less than regular price
document.getElementById('sale_price').addEventListener('blur', function() {
    const regularPrice = parseFloat(document.getElementById('price').value);
    const salePrice = parseFloat(this.value);
    
    if (salePrice && regularPrice && salePrice >= regularPrice) {
        alert('Sale price must be less than regular price');
        this.value = '';
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/admin/sarees/create.blade.php ENDPATH**/ ?>