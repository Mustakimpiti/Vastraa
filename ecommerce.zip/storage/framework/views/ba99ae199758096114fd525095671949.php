


<?php $__env->startSection('title', $collection->name . ' - Saree Collection'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Collection Banner */
.collection-banner {
    position: relative;
    height: 400px;
    background-size: cover;
    background-position: center;
    margin-bottom: 60px;
}

.collection-banner::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(to bottom, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.6) 100%);
}

.collection-banner-content {
    position: relative;
    z-index: 2;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    color: #fff;
    padding: 40px 20px;
}

.collection-banner-title {
    font-size: 48px;
    font-weight: 700;
    margin-bottom: 15px;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.collection-banner-description {
    font-size: 18px;
    max-width: 700px;
    line-height: 1.6;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
}

/* Product Grid Styling */
.product-items-style4 .product-thumb {
    position: relative;
    overflow: hidden;
    padding-bottom: 125%;
    background: #f8f9fa;
}

.product-items-style4 .product-thumb > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
}

.product-items-style4 .product-thumb img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    transition: transform 0.3s ease;
}

.product-items-style4 .product-item:hover .product-thumb img {
    transform: scale(1.05);
}

.product-items-style4 .product-thumb .badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(135deg, #ff4757 0%, #ff6b81 100%);
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 700;
    z-index: 2;
    box-shadow: 0 4px 15px rgba(255, 71, 87, 0.4);
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title-area bg-img" data-bg-img="<?php echo e($collection->banner_image ? asset($collection->banner_image) : asset('assets/img/photos/bg-page1.jpg')); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-title-content">
                    <h2 class="title"><?php echo e($collection->name); ?></h2>
                    <div class="bread-crumbs">
                        <a href="<?php echo e(route('home')); ?>">Home<span class="breadcrumb-sep">></span></a>
                        <a href="<?php echo e(route('collections')); ?>">Collections<span class="breadcrumb-sep">></span></a>
                        <span class="active"><?php echo e($collection->name); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if($collection->description): ?>
<section style="padding: 40px 0; background: #f8f9fa;">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <p style="font-size: 16px; line-height: 1.8; color: #666;"><?php echo e($collection->description); ?></p>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="product-area" style="padding: 60px 0;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="shop-toolbar-wrap">
                    <div class="shop-toolbar-left">
                        <div class="product-showing-status">
                            <?php
                                $firstItem = $sarees->firstItem() ?? 0;
                                $lastItem = $sarees->lastItem() ?? 0;
                                $total = $sarees->total();
                            ?>
                            <p class="count-result">Showing <?php echo e($firstItem); ?>–<?php echo e($lastItem); ?> of <?php echo e($total); ?> sarees</p>
                        </div>
                    </div>
                    <div class="shop-toolbar-right">
                        <div class="product-sorting-menu product-view-count">
                            <?php
                                $perPage = request('per_page', 12);
                            ?>
                            <span class="current">Show <?php echo e($perPage); ?> <i class="lastudioicon-down-arrow"></i></span>
                            <ul>
                                <li class="<?php echo e($perPage == 12 ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['per_page' => 12]))); ?>">Show 12</a>
                                </li>
                                <li class="<?php echo e($perPage == 15 ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['per_page' => 15]))); ?>">Show 15</a>
                                </li>
                                <li class="<?php echo e($perPage == 30 ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['per_page' => 30]))); ?>">Show 30</a>
                                </li>
                            </ul>
                        </div>
                        <div class="product-sorting-menu product-sorting">
                            <?php
                                $sortType = request('sort', 'default');
                                $sortLabel = 'Sort by Default';
                                switch($sortType) {
                                    case 'popularity': $sortLabel = 'Sort by Popularity'; break;
                                    case 'rating': $sortLabel = 'Sort by Rated'; break;
                                    case 'latest': $sortLabel = 'Sort by Latest'; break;
                                    case 'price_low': $sortLabel = 'Sort by Price: Low to High'; break;
                                    case 'price_high': $sortLabel = 'Sort by Price: High to Low'; break;
                                }
                            ?>
                            <span class="current"><?php echo e($sortLabel); ?> <i class="lastudioicon-down-arrow"></i></span>
                            <ul>
                                <li class="<?php echo e($sortType == 'default' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'default']))); ?>">Sort by Default</a>
                                </li>
                                <li class="<?php echo e($sortType == 'popularity' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'popularity']))); ?>">Sort by Popularity</a>
                                </li>
                                <li class="<?php echo e($sortType == 'rating' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'rating']))); ?>">Sort by Rated</a>
                                </li>
                                <li class="<?php echo e($sortType == 'latest' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'latest']))); ?>">Sort by Latest</a>
                                </li>
                                <li class="<?php echo e($sortType == 'price_low' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'price_low']))); ?>">Sort by Price: Low to High</a>
                                </li>
                                <li class="<?php echo e($sortType == 'price_high' ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('collections.show', array_merge(['slug' => $collection->slug], request()->except('page'), ['sort' => 'price_high']))); ?>">Sort by Price: High to Low</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row row-gutter-60 product-items-style4">
                    <?php $__empty_1 = true; $__currentLoopData = $sarees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-6 col-md-4 col-lg-3">
                        <div class="product-item">
                            <div class="product-thumb">
                                <a href="<?php echo e(route('product.show', $saree->slug)); ?>">
                                    <?php
                                        $imageUrl = $saree->featured_image 
                                            ? asset($saree->featured_image) 
                                            : asset('assets/img/shop/default.jpg');
                                    ?>
                                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($saree->name); ?>">
                                    <span class="thumb-overlay"></span>
                                </a>
                                <?php if($saree->hasDiscount()): ?>
                                    <?php
                                        $discount = $saree->getDiscountPercentage();
                                    ?>
                                    <span class="badge">-<?php echo e($discount); ?>%</span>
                                <?php endif; ?>
                                <div class="product-action action-style3">
                                    <a class="action-cart ht-tooltip" data-tippy-content="Add to cart" href="<?php echo e(route('product.show', $saree->slug)); ?>" title="Add to cart">
                                        <i class="lastudioicon-shopping-cart-3"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="product-info info-style2">
                                <div class="content-inner">                  
                                    <h4 class="title"><a href="<?php echo e(route('product.show', $saree->slug)); ?>"><?php echo e($saree->name); ?></a></h4>
                                    <div class="prices">
                                        <?php if($saree->hasDiscount()): ?>
                                            <?php
                                                $regularPrice = number_format($saree->price, 2);
                                                $salePrice = number_format($saree->sale_price, 2);
                                            ?>
                                            <span class="price-old">₹<?php echo e($regularPrice); ?></span>
                                            <span class="price">₹<?php echo e($salePrice); ?></span>
                                        <?php else: ?>
                                            <?php
                                                $price = number_format($saree->price, 2);
                                            ?>
                                            <span class="price">₹<?php echo e($price); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 text-center py-5">
                        <h3>No sarees found in this collection</h3>
                        <p>Check back soon for new arrivals!</p>
                        <a href="<?php echo e(route('collections')); ?>" class="btn-theme btn-black btn-border mt-3">View All Collections</a>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if($sarees->hasPages()): ?>
                <div class="pagination-area">
                    <nav>
                        <ul class="page-numbers">
                            <?php if($sarees->onFirstPage()): ?>
                                <li><span class="page-number disabled">«</span></li>
                            <?php else: ?>
                                <?php
                                    $prevUrl = $sarees->appends(request()->except('page'))->previousPageUrl();
                                ?>
                                <li><a class="page-number" href="<?php echo e($prevUrl); ?>">«</a></li>
                            <?php endif; ?>

                            <?php
                                $urlRange = $sarees->getUrlRange(1, $sarees->lastPage());
                            ?>
                            <?php $__currentLoopData = $urlRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $sarees->currentPage()): ?>
                                    <li><a class="page-number active" href="#"><?php echo e($page); ?></a></li>
                                <?php else: ?>
                                    <?php
                                        $pageUrl = $sarees->appends(request()->except('page'))->url($page);
                                    ?>
                                    <li><a class="page-number" href="<?php echo e($pageUrl); ?>"><?php echo e($page); ?></a></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($sarees->hasMorePages()): ?>
                                <?php
                                    $nextUrl = $sarees->appends(request()->except('page'))->nextPageUrl();
                                ?>
                                <li><a class="page-number next" href="<?php echo e($nextUrl); ?>"><i class="icofont-long-arrow-right"></i></a></li>
                            <?php else: ?>
                                <li><span class="page-number disabled">»</span></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/pages/shop-collection-detail.blade.php ENDPATH**/ ?>