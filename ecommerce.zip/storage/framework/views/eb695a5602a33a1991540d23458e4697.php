

<?php $__env->startSection('title', 'Order Success - Saree Shop'); ?>

<?php $__env->startSection('content'); ?>
<!--== Start Page Title Area ==-->
<section class="page-title-area bg-img" data-bg-img="<?php echo e(asset('assets/img/photos/bg-page1.jpg')); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-title-content">
                    <h2 class="title">Order Confirmation</h2>
                    <div class="bread-crumbs">
                        <a href="<?php echo e(route('home')); ?>">Home<span class="breadcrumb-sep">></span></a>
                        <span class="active">Order Success</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== End Page Title Area ==-->

<!--== Start Order Success Area ==-->
<section class="shop-checkout-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <!-- Success Message -->
                <div class="order-success-message text-center mb-5">
                    <div class="success-icon mb-4">
                        <i class="lastudioicon-check-circle" style="font-size: 80px; color: #28a745;"></i>
                    </div>
                    <h2 class="title mb-3">Thank you for your order!</h2>
                    <p class="lead mb-4">Your order has been successfully placed and is being processed.</p>
                    <div class="alert alert-success d-inline-block px-5 py-3">
                        <strong>Order Number:</strong> <span style="font-size: 1.2em;"><?php echo e($order->order_number); ?></span>
                    </div>
                    <p class="mt-3">We've sent an order confirmation email to <strong><?php echo e($order->email); ?></strong></p>
                </div>

                <!-- Order Details -->
                <div class="shop-billing-form mb-4">
                    <h4 class="title">Order Details</h4>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="order-info-box">
                                <h5 class="mb-3">Billing Address</h5>
                                <address style="line-height: 1.8;">
                                    <strong><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></strong><br>
                                    <?php echo e($order->street_address); ?><br>
                                    <?php if($order->apartment): ?>
                                        <?php echo e($order->apartment); ?><br>
                                    <?php endif; ?>
                                    <?php echo e($order->city); ?>, <?php echo e($order->state); ?> <?php echo e($order->zip); ?><br>
                                    <?php echo e($order->country); ?><br>
                                    <strong>Phone:</strong> <?php echo e($order->phone); ?><br>
                                    <strong>Email:</strong> <?php echo e($order->email); ?>

                                </address>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="order-info-box">
                                <?php if($order->ship_to_different): ?>
                                <h5 class="mb-3">Shipping Address</h5>
                                <address style="line-height: 1.8;">
                                    <strong><?php echo e($order->shipping_first_name); ?> <?php echo e($order->shipping_last_name); ?></strong><br>
                                    <?php echo e($order->shipping_street_address); ?><br>
                                    <?php if($order->shipping_apartment): ?>
                                        <?php echo e($order->shipping_apartment); ?><br>
                                    <?php endif; ?>
                                    <?php echo e($order->shipping_city); ?>, <?php echo e($order->shipping_state); ?> <?php echo e($order->shipping_zip); ?><br>
                                    <?php echo e($order->shipping_country); ?>

                                </address>
                                <?php else: ?>
                                <h5 class="mb-3">Shipping Address</h5>
                                <p><em>Same as billing address</em></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="order-info-box">
                                <h5 class="mb-3">Payment Method</h5>
                                <p class="mb-0">
                                    <?php switch($order->payment_method):
                                        case ('cod'): ?>
                                            <i class="lastudioicon-e-remove"></i> Cash on Delivery
                                            <?php break; ?>
                                        <?php case ('bank_transfer'): ?>
                                            <i class="lastudioicon-e-remove"></i> Direct Bank Transfer
                                            <?php break; ?>
                                        <?php case ('paypal'): ?>
                                            <i class="lastudioicon-e-remove"></i> PayPal
                                            <?php break; ?>
                                        <?php default: ?>
                                            <?php echo e(ucfirst($order->payment_method)); ?>

                                    <?php endswitch; ?>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="order-info-box">
                                <h5 class="mb-3">Order Status</h5>
                                <p class="mb-0">
                                    <span class="badge bg-warning text-dark" style="font-size: 0.9em; padding: 5px 15px;"><?php echo e(ucfirst($order->order_status)); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>

                    <?php if($order->order_notes): ?>
                    <div class="row">
                        <div class="col-12 mb-4">
                            <div class="order-info-box">
                                <h5 class="mb-3">Order Notes</h5>
                                <p class="mb-0"><?php echo e($order->order_notes); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Order Items -->
                <h4 class="title">Your Order</h4>
                <div class="order-review-details mb-4">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Fabric</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="product-title"><?php echo e($item->saree_name); ?></span><br>
                                    <small class="text-muted">SKU: <?php echo e($item->saree_sku); ?></small>
                                </td>
                                <td><?php echo e(ucfirst($item->fabric)); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>₹<?php echo e(number_format($item->price, 2)); ?></td>
                                <td>₹<?php echo e(number_format($item->getSubtotal(), 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="cart-subtotal">
                                <th colspan="4">Subtotal</th>
                                <td>₹<?php echo e(number_format($order->subtotal, 2)); ?></td>
                            </tr>
                            <?php if($order->discount > 0): ?>
                            <tr>
                                <th colspan="4">Discount</th>
                                <td class="text-success">-₹<?php echo e(number_format($order->discount, 2)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr class="shipping">
                                <th colspan="4">Shipping</th>
                                <td>₹<?php echo e(number_format($order->shipping_cost, 2)); ?></td>
                            </tr>
                            <tr class="final-total">
                                <th colspan="4">Total</th>
                                <td><span class="total-amount">₹<?php echo e(number_format($order->total, 2)); ?></span></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Action Buttons -->
                <div class="text-center mt-5">
                    <a href="<?php echo e(route('shop')); ?>" class="btn btn-theme btn-black me-3">
                        <i class="lastudioicon-arrow-left"></i> Continue Shopping
                    </a>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-theme">
                        <i class="lastudioicon-home-2"></i> Go to Home
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--== End Order Success Area ==-->

<?php $__env->startPush('styles'); ?>
<style>
.order-success-message {
    background: white;
    padding: 50px 30px;
    border-radius: 8px;
    box-shadow: 0 0 20px rgba(0,0,0,0.08);
}

.order-info-box {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 5px;
    height: 100%;
}

.order-info-box h5 {
    font-size: 16px;
    font-weight: 600;
    border-bottom: 2px solid #ddd;
    padding-bottom: 10px;
    margin-bottom: 15px;
}

.order-info-box address {
    margin-bottom: 0;
}

.table thead th {
    background: #f8f9fa;
    font-weight: 600;
    border-bottom: 2px solid #dee2e6;
}

.btn-theme {
    padding: 12px 30px;
    font-size: 14px;
    font-weight: 500;
}

@media (max-width: 768px) {
    .order-success-message {
        padding: 30px 20px;
    }
    
    .btn-theme {
        display: block;
        width: 100%;
        margin-bottom: 10px;
    }
    
    .me-3 {
        margin-right: 0 !important;
    }
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/pages/order-success.blade.php ENDPATH**/ ?>