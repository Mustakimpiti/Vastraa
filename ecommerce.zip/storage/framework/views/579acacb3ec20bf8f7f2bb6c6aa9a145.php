

<?php $__env->startSection('title', 'Shop Sarees - Clothing Shop'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* Product Image Uniform Sizing - Shop Page */
.product-items-style4 .product-thumb {
    position: relative;
    overflow: hidden;
    padding-bottom: 125%; /* 4:5 aspect ratio like related products */
    background: #f8f9fa;
}

.product-items-style4 .product-thumb > a {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
}

.product-items-style4 .product-thumb img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
    transition: transform 0.3s ease;
}

.product-items-style4 .product-item:hover .product-thumb img {
    transform: scale(1.05);
}

.product-items-style4 .product-thumb .thumb-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

/* Attractive Badge Styling - No Overlap */
.product-items-style4 .product-thumb .badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(135deg, #ff4757 0%, #ff6b81 100%);
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 700;
    z-index: 2;
    box-shadow: 0 4px 15px rgba(255, 71, 87, 0.4);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
}

.product-items-style4 .product-thumb .product-action {
    position: absolute;
    z-index: 3;
}

/* Reduce spacing between widgets */
.shop-sidebar-area .widget {
    margin-bottom: 30px !important;
}

.widget-title {
    margin-bottom: 15px !important;
}

/* Price Filter Slider Styling - Template Style */
.irs--flat .irs-line {
    background-color: #e0e0e0 !important;
    height: 4px !important;
}

.irs--flat .irs-bar {
    background-color: #00bcd4 !important;
    height: 4px !important;
}

.irs--flat .irs-handle {
    width: 16px !important;
    height: 16px !important;
    top: 50% !important;
    transform: translateY(-50%) !important;
}

.irs--flat .irs-handle > i:first-child {
    background-color: #00bcd4 !important;
    width: 16px !important;
    height: 16px !important;
    border-radius: 50% !important;
    border: 3px solid #fff !important;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
}

.irs--flat .irs-handle.state_hover > i:first-child,
.irs--flat .irs-handle:hover > i:first-child {
    background-color: #00acc1 !important;
}

.irs--flat .irs-from, 
.irs--flat .irs-to, 
.irs--flat .irs-single {
    display: none !important;
}

.irs--flat .irs-min,
.irs--flat .irs-max {
    display: none !important;
}

/* Price range labels */
.slider-labels {
    display: flex;
    align-items: center;
    margin-top: 15px;
    margin-bottom: 15px;
    font-size: 14px;
}

.range-price-title {
    font-weight: 500;
    margin-right: 8px;
}

.slider-labels .caption {
    display: inline-block;
}

.slider-labels .caption span {
    color: #333;
    font-weight: 500;
}

.range-separator {
    margin: 0 8px;
    color: #999;
}

/* Filter button */
.btn-filter {
    display: inline-block;
    background-color: #000 !important;
    color: #fff !important;
    border: 1px solid #000 !important;
    padding: 10px 30px;
    text-transform: uppercase;
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 1px;
    transition: all 0.3s ease;
    cursor: pointer;
    text-decoration: none;
}

.btn-filter:hover {
    background-color: #fff !important;
    color: #000 !important;
}

/* Hide the number inputs - use only slider */
.price-inputs {
    display: none;
}

/* Checkbox Filter Styling */
.filter-checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    padding: 6px 0;
    transition: all 0.3s ease;
}

.filter-checkbox-label:hover {
    color: #000;
}

.filter-checkbox {
    width: 18px;
    height: 18px;
    margin-right: 10px;
    cursor: pointer;
    accent-color: #00bcd4;
}

.filter-checkbox-label span {
    user-select: none;
}

.widget-size-menu ul li {
    list-style: none;
    margin: 0;
    padding: 0;
}

.widget-size-menu ul {
    padding: 0;
    margin: 0;
}

.widget-size-menu,
.widget-custom-menu {
    margin-top: 15px;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<section class="page-title-area bg-img" data-bg-img="<?php echo e(asset('assets/img/photos/bg-page1.jpg')); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-title-content">
                    <h2 class="title">Shop</h2>
                    <div class="bread-crumbs">
                        <a href="<?php echo e(route('home')); ?>">Home<span class="breadcrumb-sep">></span></a>
                        <span class="active">Shop</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="product-area product-shop-inner-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 order-1 order-lg-0">
                <div class="sidebar-area inner-right-padding shop-sidebar-area">
                    
                    <div class="widget">
                        <div class="widget-search-box">
                            <form action="<?php echo e(route('shop')); ?>" method="get">
                                <?php $__currentLoopData = request()->except(['search', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-input-item">
                                    <label for="search2" class="sr-only">Search Here</label>
                                    <input type="text" id="search2" name="search" placeholder="Search entire store…" value="<?php echo e(request('search')); ?>">
                                    <button type="submit" class="btn-src">
                                        <i class="icofont-search-1"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="widget">
                        <h3 class="widget-title">Collections</h3>
                        <div class="widget-custom-menu">
                            <ul>
                                <li class="<?php echo e(!request('collection') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('shop', array_merge(request()->except(['collection', 'page'])))); ?>">All Collections</a>
                                </li>
                                <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(request('collection') == $collection->id ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['collection' => $collection->id]))); ?>">
                                        <?php echo e($collection->name); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                    <div class="widget">
                        <h4 class="widget-title">By price</h4>
                        <div class="widget-price-filter">
                            <form id="price-filter-form" action="<?php echo e(route('shop')); ?>" method="get">
                                <?php $__currentLoopData = request()->except(['min_price', 'max_price', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $minVal = request('min_price', $priceRange['min']);
                                    $maxVal = request('max_price', $priceRange['max']);
                                ?>
                                
                                <div class="price-inputs mb-3">
                                    <div class="d-flex gap-2">
                                        <input type="number" name="min_price" id="min_price" class="form-control" placeholder="Min" value="<?php echo e($minVal); ?>" min="<?php echo e($priceRange['min']); ?>" max="<?php echo e($priceRange['max']); ?>">
                                        <input type="number" name="max_price" id="max_price" class="form-control" placeholder="Max" value="<?php echo e($maxVal); ?>" min="<?php echo e($priceRange['min']); ?>" max="<?php echo e($priceRange['max']); ?>">
                                    </div>
                                </div>
                                
                                <div class="slider-range" id="slider-range"></div>
                                <div class="slider-labels">
                                    <span class="range-price-title">Price:</span>
                                    <div class="caption">
                                        <span id="slider-range-value1">₹<?php echo e(number_format($minVal)); ?></span>
                                    </div>
                                    <span class="range-separator"> — </span>
                                    <div class="caption">
                                        <span id="slider-range-value2">₹<?php echo e(number_format($maxVal)); ?></span>
                                    </div>
                                </div>
                                <button type="submit" class="btn-filter">Filter</button>
                            </form>
                        </div>
                    </div>

                    <?php if($fabrics->count() > 0): ?>
                    <div class="widget">
                        <h4 class="widget-title">By Fabric</h4>
                        <div class="widget-size-menu">
                            <ul>
                                <?php $__currentLoopData = $fabrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(request('fabric') == $fabric ? 'active' : ''); ?>">
                                    <label class="filter-checkbox-label">
                                        <input type="checkbox" class="filter-checkbox" 
                                               <?php echo e(request('fabric') == $fabric ? 'checked' : ''); ?>

                                               onchange="window.location.href='<?php echo e(request('fabric') == $fabric ? route('shop', array_merge(request()->except(['fabric', 'page']))) : route('shop', array_merge(request()->except('page'), ['fabric' => $fabric]))); ?>'">
                                        <span><?php echo e($fabric); ?></span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($occasions->count() > 0): ?>
                    <div class="widget">
                        <h4 class="widget-title">By Occasion</h4>
                        <div class="widget-size-menu">
                            <ul>
                                <?php $__currentLoopData = $occasions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(request('occasion') == $occasion ? 'active' : ''); ?>">
                                    <label class="filter-checkbox-label">
                                        <input type="checkbox" class="filter-checkbox" 
                                               <?php echo e(request('occasion') == $occasion ? 'checked' : ''); ?>

                                               onchange="window.location.href='<?php echo e(request('occasion') == $occasion ? route('shop', array_merge(request()->except(['occasion', 'page']))) : route('shop', array_merge(request()->except('page'), ['occasion' => $occasion]))); ?>'">
                                        <span><?php echo e($occasion); ?></span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($workTypes->count() > 0): ?>
                    <div class="widget">
                        <h4 class="widget-title">By Work Type</h4>
                        <div class="widget-size-menu">
                            <ul>
                                <?php $__currentLoopData = $workTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(request('work_type') == $workType ? 'active' : ''); ?>">
                                    <label class="filter-checkbox-label">
                                        <input type="checkbox" class="filter-checkbox" 
                                               <?php echo e(request('work_type') == $workType ? 'checked' : ''); ?>

                                               onchange="window.location.href='<?php echo e(request('work_type') == $workType ? route('shop', array_merge(request()->except(['work_type', 'page']))) : route('shop', array_merge(request()->except('page'), ['work_type' => $workType]))); ?>'">
                                        <span><?php echo e($workType); ?></span>
                                    </label>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(count(request()->except('page')) > 0): ?>   
                    <div class="widget">
                        <a href="<?php echo e(route('shop')); ?>" class="btn-theme btn-black btn-border w-100">Clear All Filters</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-lg-9 order-0 order-lg-1">
                <div class="inner-left-padding">
                    <div class="shop-toolbar-wrap">
                        <div class="shop-toolbar-left">
                            <div class="product-showing-status">
                                <?php
                                    $firstItem = $sarees->firstItem() ?? 0;
                                    $lastItem = $sarees->lastItem() ?? 0;
                                    $total = $sarees->total();
                                ?>
                                <p class="count-result">Showing <?php echo e($firstItem); ?>–<?php echo e($lastItem); ?> of <?php echo e($total); ?> results</p>
                            </div>
                        </div>
                        <div class="shop-toolbar-right">
                            <div class="product-sorting-menu product-view-count">
                                <?php
                                    $perPage = request('per_page', 12);
                                ?>
                                <span class="current">Show <?php echo e($perPage); ?> <i class="lastudioicon-down-arrow"></i></span>
                                <ul>
                                    <li class="<?php echo e($perPage == 12 ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['per_page' => 12]))); ?>">Show 12</a>
                                    </li>
                                    <li class="<?php echo e($perPage == 15 ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['per_page' => 15]))); ?>">Show 15</a>
                                    </li>
                                    <li class="<?php echo e($perPage == 30 ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['per_page' => 30]))); ?>">Show 30</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="product-sorting-menu product-sorting">
                                <?php
                                    $sortType = request('sort', 'default');
                                    $sortLabel = 'Sort by Default';
                                    switch($sortType) {
                                        case 'popularity': $sortLabel = 'Sort by Popularity'; break;
                                        case 'rating': $sortLabel = 'Sort by Rated'; break;
                                        case 'latest': $sortLabel = 'Sort by Latest'; break;
                                        case 'price_low': $sortLabel = 'Sort by Price: Low to High'; break;
                                        case 'price_high': $sortLabel = 'Sort by Price: High to Low'; break;
                                    }
                                ?>
                                <span class="current"><?php echo e($sortLabel); ?> <i class="lastudioicon-down-arrow"></i></span>
                                <ul>
                                    <li class="<?php echo e($sortType == 'default' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'default']))); ?>">Sort by Default</a>
                                    </li>
                                    <li class="<?php echo e($sortType == 'popularity' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'popularity']))); ?>">Sort by Popularity</a>
                                    </li>
                                    <li class="<?php echo e($sortType == 'rating' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'rating']))); ?>">Sort by Rated</a>
                                    </li>
                                    <li class="<?php echo e($sortType == 'latest' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'latest']))); ?>">Sort by Latest</a>
                                    </li>
                                    <li class="<?php echo e($sortType == 'price_low' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'price_low']))); ?>">Sort by Price: Low to High</a>
                                    </li>
                                    <li class="<?php echo e($sortType == 'price_high' ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('shop', array_merge(request()->except('page'), ['sort' => 'price_high']))); ?>">Sort by Price: High to Low</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row row-gutter-60 product-items-style4">
<?php $__empty_1 = true; $__currentLoopData = $sarees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="col-sm-6 col-md-4">
    <div class="product-item">
        <div class="product-thumb">
            <a href="<?php echo e(route('product.show', $saree->slug)); ?>">
                <?php
                    // Changed from asset('storage/') to asset() directly
                    $imageUrl = $saree->featured_image 
                        ? asset($saree->featured_image) 
                        : asset('assets/img/shop/default.jpg');
                ?>
                <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($saree->name); ?>">
                <span class="thumb-overlay"></span>
            </a>
                                    <?php if($saree->hasDiscount()): ?>
                                    <?php
                                        $discount = $saree->getDiscountPercentage();
                                    ?>
                                    <span class="badge">-<?php echo e($discount); ?>%</span>
                                    <?php endif; ?>
                                    <div class="product-action action-style3">
                                        <a class="action-cart ht-tooltip" data-tippy-content="Add to cart" href="<?php echo e(route('product.show', $saree->slug)); ?>" title="Add to cart">
                                            <i class="lastudioicon-shopping-cart-3"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="product-info info-style2">
                                    <div class="content-inner">                  
                                        <h4 class="title"><a href="<?php echo e(route('product.show', $saree->slug)); ?>"><?php echo e($saree->name); ?></a></h4>
                                        <div class="prices">
                                            <?php if($saree->hasDiscount()): ?>
                                                <?php
                                                    $regularPrice = number_format($saree->price, 2);
                                                    $salePrice = number_format($saree->sale_price, 2);
                                                ?>
                                                <span class="price-old">₹<?php echo e($regularPrice); ?></span>
                                                <span class="price">₹<?php echo e($salePrice); ?></span>
                                            <?php else: ?>
                                                <?php
                                                    $price = number_format($saree->price, 2);
                                                ?>
                                                <span class="price">₹<?php echo e($price); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12 text-center py-5">
                            <h3>No sarees found</h3>
                            <p>Try adjusting your filters or search criteria</p>
                            <a href="<?php echo e(route('shop')); ?>" class="btn-theme btn-black btn-border mt-3">Clear Filters</a>
                        </div>
                        <?php endif; ?>
                    </div>

                    <?php if($sarees->hasPages()): ?>
                    <div class="pagination-area">
                        <nav>
                            <ul class="page-numbers">
                                <?php if($sarees->onFirstPage()): ?>
                                    <li><span class="page-number disabled">«</span></li>
                                <?php else: ?>
                                    <?php
                                        $prevUrl = $sarees->appends(request()->except('page'))->previousPageUrl();
                                    ?>
                                    <li><a class="page-number" href="<?php echo e($prevUrl); ?>">«</a></li>
                                <?php endif; ?>

                                <?php
                                    $urlRange = $sarees->getUrlRange(1, $sarees->lastPage());
                                ?>
                                <?php $__currentLoopData = $urlRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page == $sarees->currentPage()): ?>
                                        <li><a class="page-number active" href="#"><?php echo e($page); ?></a></li>
                                    <?php else: ?>
                                        <?php
                                            $pageUrl = $sarees->appends(request()->except('page'))->url($page);
                                        ?>
                                        <li><a class="page-number" href="<?php echo e($pageUrl); ?>"><?php echo e($page); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if($sarees->hasMorePages()): ?>
                                    <?php
                                        $nextUrl = $sarees->appends(request()->except('page'))->nextPageUrl();
                                    ?>
                                    <li><a class="page-number next" href="<?php echo e($nextUrl); ?>"><i class="icofont-long-arrow-right"></i></a></li>
                                <?php else: ?>
                                    <li><span class="page-number disabled">»</span></li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/js/ion.rangeSlider.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.1/css/ion.rangeSlider.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    var minPrice = <?php echo e($priceRange['min']); ?>;
    var maxPrice = <?php echo e($priceRange['max']); ?>;
    var currentMin = <?php echo e(request('min_price', $priceRange['min'])); ?>;
    var currentMax = <?php echo e(request('max_price', $priceRange['max'])); ?>;
    
    var slider = document.getElementById('slider-range');
    if (slider && typeof $.fn.ionRangeSlider !== 'undefined') {
        $(slider).ionRangeSlider({
            type: 'double',
            min: minPrice,
            max: maxPrice,
            from: currentMin,
            to: currentMax,
            prefix: '₹',
            onChange: function(data) {
                document.getElementById('min_price').value = data.from;
                document.getElementById('max_price').value = data.to;
                document.getElementById('slider-range-value1').textContent = '₹' + data.from.toLocaleString();
                document.getElementById('slider-range-value2').textContent = '₹' + data.to.toLocaleString();
            }
        });
    }
    
    var minInput = document.getElementById('min_price');
    var maxInput = document.getElementById('max_price');
    
    if (minInput && maxInput && slider) {
        var sliderInstance = $(slider).data('ionRangeSlider');
        
        minInput.addEventListener('change', function() {
            if (sliderInstance) {
                sliderInstance.update({
                    from: this.value
                });
            }
        });
        
        maxInput.addEventListener('change', function() {
            if (sliderInstance) {
                sliderInstance.update({
                    to: this.value
                });
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Mustakim\Vastraa\Ecommerce_app\resources\views/pages/shop.blade.php ENDPATH**/ ?>